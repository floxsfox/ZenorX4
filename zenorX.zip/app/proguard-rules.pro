# zenorX - aturan R8 untuk build release
-keep class com.zenorx.files.FilesViewModel { <init>(android.app.Application); }
-keep class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class * extends androidx.lifecycle.AndroidViewModel { <init>(android.app.Application); }
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontwarn org.jetbrains.annotations.**
-dontwarn net.lingala.zip4j.**
