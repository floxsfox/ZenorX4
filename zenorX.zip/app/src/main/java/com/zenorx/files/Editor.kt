package com.zenorx.files

import android.graphics.Paint
import android.graphics.Typeface
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Arrays

private val EditorBg = Color(0xFF2B2B2B)
private val GutterBg = Color(0xFF313335)
private val BarBg = Color(0xFF1E1F22)

/** Riwayat undo/redo berbasis snapshot teks. */
class UndoStack {
    private val undoList = ArrayList<TextFieldValue>()
    private val redoList = ArrayList<TextFieldValue>()
    private var last = 0L
    private var version by mutableIntStateOf(0)

    val canUndo: Boolean get() = version >= 0 && undoList.isNotEmpty()
    val canRedo: Boolean get() = version >= 0 && redoList.isNotEmpty()

    fun record(prev: TextFieldValue) {
        val now = SystemClock.uptimeMillis()
        if (undoList.isEmpty() || now - last > 700) {
            undoList.add(prev)
            val cap = maxOf(10, minOf(100, 4_000_000 / (prev.text.length + 1)))
            while (undoList.size > cap) undoList.removeAt(0)
        }
        last = now
        redoList.clear()
        version++
    }

    fun undo(cur: TextFieldValue): TextFieldValue? {
        if (undoList.isEmpty()) return null
        redoList.add(cur)
        val v = undoList.removeAt(undoList.size - 1)
        last = 0L
        version++
        return v
    }

    fun redo(cur: TextFieldValue): TextFieldValue? {
        if (redoList.isEmpty()) return null
        undoList.add(cur)
        val v = redoList.removeAt(redoList.size - 1)
        last = 0L
        version++
        return v
    }
}

class HighlightTransformation(private val spec: LangSpec) : VisualTransformation {
    private var lastText: String? = null
    private var lastOut: AnnotatedString? = null

    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        var out = lastOut
        if (out == null || s != lastText) {
            out = highlight(s, spec)
            lastText = s
            lastOut = out
        }
        return TransformedText(out, OffsetMapping.Identity)
    }
}

fun computeLineStarts(t: String): IntArray {
    var n = 1
    for (ch in t) if (ch == '\n') n++
    val a = IntArray(n)
    var k = 1
    for (i in t.indices) {
        if (t[i] == '\n') {
            a[k] = i + 1
            k++
        }
    }
    return a
}

fun lineIndexOf(starts: IntArray, offset: Int): Int {
    var idx = Arrays.binarySearch(starts, offset)
    if (idx < 0) idx = -idx - 2
    if (idx < 0) idx = 0
    return idx
}

class Guides(val levels: IntArray, val unit: Int)

private fun gcd(a: Int, b: Int): Int {
    var x = a
    var y = b
    while (y != 0) {
        val r = x % y
        x = y
        y = r
    }
    return x
}

/** Tingkat garis indentasi per baris; baris kosong mewarisi tingkat sekitarnya agar garis menyambung. */
fun computeGuides(t: String, starts: IntArray): Guides {
    val n = starts.size
    val ind = IntArray(n)
    var g = 0
    for (li in 0 until n) {
        val s = starts[li]
        val e = if (li + 1 < n) starts[li + 1] - 1 else t.length
        var c = 0
        var k = s
        while (k < e) {
            val ch = t[k]
            if (ch == ' ') c++ else if (ch == '\t') c += 4 else break
            k++
        }
        if (k < e && t[k] != '\r') {
            ind[li] = c
            if (c > 0) g = gcd(g, c)
        } else {
            ind[li] = -1
        }
    }
    val unit = when {
        g <= 0 -> 4
        g == 1 -> 2
        g > 8 -> 4
        else -> g
    }
    val prevInd = IntArray(n)
    var last = 0
    for (li in 0 until n) {
        if (ind[li] >= 0) last = ind[li]
        prevInd[li] = last
    }
    val levels = IntArray(n)
    var next = 0
    for (li in n - 1 downTo 0) {
        if (ind[li] >= 0) {
            next = ind[li]
            levels[li] = ind[li] / unit
        } else {
            levels[li] = minOf(prevInd[li], next) / unit
        }
    }
    return Guides(levels, unit)
}

private fun autoIndent(old: TextFieldValue, nv: TextFieldValue, unit: String, colonBlocks: Boolean): TextFieldValue {
    if (nv.text.length != old.text.length + 1) return nv
    val cur = nv.selection.start
    if (!nv.selection.collapsed || cur < 1 || nv.text[cur - 1] != '\n') return nv
    val ls = nv.text.lastIndexOf('\n', cur - 2) + 1
    val prev = nv.text.substring(ls, cur - 1)
    var ind = prev.takeWhile { it == ' ' || it == '\t' }
    val trimmed = prev.trimEnd()
    if (trimmed.endsWith("{") || trimmed.endsWith("(") || trimmed.endsWith("[") ||
        (colonBlocks && trimmed.endsWith(":"))
    ) {
        ind += unit
    }
    if (ind.isEmpty()) return nv
    val t2 = nv.text.substring(0, cur) + ind + nv.text.substring(cur)
    return TextFieldValue(t2, TextRange(cur + ind.length))
}

private fun DrawScope.drawDecor(
    layout: TextLayoutResult,
    starts: IntArray,
    g: Guides,
    charPx: Float,
    scrollY: Int,
    viewH: Int,
    padTopPx: Float,
    cursor: Int,
    result: CheckResult?
) {
    val top = (scrollY - padTopPx).coerceAtLeast(0f)
    val first = layout.getLineForVerticalPosition(top)
    val last = layout.getLineForVerticalPosition(top + viewH)
    val curLine = layout.getLineForOffset(cursor.coerceIn(0, layout.layoutInput.text.length))
    val guideColor = Color(0x26FFFFFF)
    for (li in first..last) {
        val lt = layout.getLineTop(li)
        val lb = layout.getLineBottom(li)
        val idx = lineIndexOf(starts, layout.getLineStart(li))
        if (result != null) {
            val err = result.errors.containsKey(idx)
            drawRect(if (err) Color(0x44FF4D4D) else Color(0x1F3FBF6F), Offset(0f, lt), Size(size.width, lb - lt))
        }
        if (li == curLine) drawRect(Color(0x0DFFFFFF), Offset(0f, lt), Size(size.width, lb - lt))
        val lvl = if (idx < g.levels.size) g.levels[idx] else 0
        var k = 0
        while (k < lvl) {
            val x = k * g.unit * charPx + 1f
            drawLine(guideColor, Offset(x, lt), Offset(x, lb), 1f)
            k++
        }
    }
}

private fun DrawScope.drawGutter(
    layout: TextLayoutResult,
    starts: IntArray,
    paint: Paint,
    rightX: Float,
    scrollY: Int,
    viewH: Int,
    padTopPx: Float,
    result: CheckResult?
) {
    val top = (scrollY - padTopPx).coerceAtLeast(0f)
    val first = layout.getLineForVerticalPosition(top)
    val last = layout.getLineForVerticalPosition(top + viewH)
    drawIntoCanvas { canvas ->
        for (li in first..last) {
            val off = layout.getLineStart(li)
            val idx = lineIndexOf(starts, off)
            val isFirst = starts[idx] == off
            val err = result != null && result.errors.containsKey(idx)
            paint.color = when {
                err -> 0xFFFF6B6B.toInt()
                result != null -> 0xFF5FD38D.toInt()
                else -> 0xFF7A7E85.toInt()
            }
            val lt = layout.getLineTop(li)
            val lb = layout.getLineBottom(li)
            val y = (lt + lb) / 2f - (paint.ascent() + paint.descent()) / 2f
            canvas.nativeCanvas.drawText(if (isFirst) (idx + 1).toString() else "↳", rightX, y, paint)
        }
    }
}

private val symbols = listOf(
    "/", "+", "-", "*", "=", "<", ">", "(", ")", "{", "}", "[", "]", "\"", "'", ";", ":", "#",
    "_", "&", "|", "\\", "!", "$", "%", "?", ",", "."
)

@Composable
fun CodeEditorDialog(vm: FilesViewModel, file: File) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val spec = remember(file) { specFor(file) }
    val runKind = remember(file) { runKindOf(spec.lang, file.extension.lowercase()) }

    var tfv by remember(file) { mutableStateOf(TextFieldValue("")) }
    var saved by remember(file) { mutableStateOf<String?>(null) }
    val undo = remember(file) { UndoStack() }
    var layout by remember(file) { mutableStateOf<TextLayoutResult?>(null) }
    val vscroll = rememberScrollState()
    val hscroll = rememberScrollState()
    var wrap by remember { mutableStateOf(true) }
    var fontSp by remember { mutableStateOf(13f) }
    var result by remember(file) { mutableStateOf<CheckResult?>(null) }
    var confirmClose by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var gotoOpen by remember { mutableStateOf(false) }
    var gotoText by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<PreviewReq?>(null) }
    var viewportH by remember { mutableStateOf(0) }

    LaunchedEffect(file) {
        val s = withContext(Dispatchers.IO) {
            try { file.readText() } catch (e: Exception) { null }
        }
        if (s == null) {
            vm.toast(ctx.getString(R.string.t_read_failed))
            vm.editing = null
        } else {
            saved = s
            tfv = TextFieldValue(s)
        }
    }

    val text = tfv.text
    val dirty = saved != null && text != saved
    val lineStarts = remember(text) { computeLineStarts(text) }
    val guides = remember(text) { computeGuides(text, lineStarts) }
    val transform = remember(spec) { HighlightTransformation(spec) }
    val padTopDp = 6.dp
    val padTopPx = with(density) { padTopDp.toPx() }
    val style = remember(fontSp) {
        TextStyle(
            color = Syn.plain, fontSize = fontSp.sp, fontFamily = FontFamily.Monospace,
            lineHeight = (fontSp * 1.5f).sp
        )
    }
    val charPx = remember(fontSp, density) {
        val p = Paint()
        p.typeface = Typeface.MONOSPACE
        p.textSize = with(density) { fontSp.sp.toPx() }
        p.measureText("0")
    }
    val numPaint = remember(fontSp, density) {
        val p = Paint()
        p.isAntiAlias = true
        p.typeface = Typeface.MONOSPACE
        p.textSize = with(density) { (fontSp * 0.85f).sp.toPx() }
        p.textAlign = Paint.Align.RIGHT
        p
    }
    val digits = maxOf(2, lineStarts.size.toString().length)
    val gutterWpx = digits * numPaint.measureText("0") + with(density) { 20.dp.toPx() }
    val gutterW = with(density) { gutterWpx.toDp() }
    val layoutH = layout?.size?.height ?: 0
    val contentHpx = maxOf(layoutH, viewportH)
    val contentH = with(density) { contentHpx.toDp() }

    val cursorLine = lineIndexOf(lineStarts, tfv.selection.start)
    val cursorCol = tfv.selection.start - lineStarts[cursorLine] + 1
    val unitStr = " ".repeat(guides.unit)
    val colonBlocks = spec.lang == Lang.PYTHON || spec.lang == Lang.YAML

    fun handleChange(nv: TextFieldValue) {
        var v = nv
        if (v.text != tfv.text) {
            undo.record(tfv)
            v = autoIndent(tfv, v, unitStr, colonBlocks)
            result = null
        }
        tfv = v
    }

    fun insert(sym: String) {
        val sel = tfv.selection
        val t = tfv.text
        val nt = t.substring(0, sel.min) + sym + t.substring(sel.max)
        handleChange(TextFieldValue(nt, TextRange(sel.min + sym.length)))
    }

    fun jumpToLine(idx: Int) {
        val l = layout ?: return
        val i = idx.coerceIn(0, lineStarts.size - 1)
        val li = l.getLineForOffset(lineStarts[i])
        val y = padTopPx + l.getLineTop(li)
        scope.launch { vscroll.animateScrollTo((y - 140f).toInt().coerceAtLeast(0)) }
    }

    fun runCheck() {
        if (!supportsCheck(spec.lang)) {
            vm.toast(ctx.getString(R.string.check_unsupported))
            return
        }
        val snapshot = tfv.text
        scope.launch {
            val r = withContext(Dispatchers.Default) { checkCode(snapshot, spec) }
            if (tfv.text == snapshot) {
                result = r
                if (r.errors.isEmpty()) vm.toast(ctx.getString(R.string.check_ok))
                else jumpToLine(r.errors.keys.minOrNull() ?: 0)
            }
        }
    }

    fun save() {
        val t = tfv.text
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { file.writeText(t); true } catch (e: Exception) { false }
            }
            if (ok) {
                saved = t
                vm.toast(ctx.getString(R.string.t_saved))
                vm.refreshAll()
            } else {
                vm.toast(ctx.getString(R.string.t_save_failed))
            }
        }
    }

    fun tryClose() {
        if (dirty) confirmClose = true else vm.editing = null
    }

    Dialog(
        onDismissRequest = { tryClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = EditorBg) {
            Column(Modifier.fillMaxSize()) {
                // ── bar atas ──
                Surface(color = BarBg, contentColor = Color.White) {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { tryClose() }, modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Filled.Close, stringResource(R.string.close))
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(
                                onClick = { undo.undo(tfv)?.let { tfv = it; result = null } },
                                enabled = undo.canUndo, modifier = Modifier.size(42.dp)
                            ) {
                                Icon(
                                    Icons.Filled.Undo, stringResource(R.string.cd_undo),
                                    tint = if (undo.canUndo) Color.White else Color(0xFF666666)
                                )
                            }
                            IconButton(
                                onClick = { undo.redo(tfv)?.let { tfv = it; result = null } },
                                enabled = undo.canRedo, modifier = Modifier.size(42.dp)
                            ) {
                                Icon(
                                    Icons.Filled.Redo, stringResource(R.string.cd_redo),
                                    tint = if (undo.canRedo) Color.White else Color(0xFF666666)
                                )
                            }
                            IconButton(onClick = { runCheck() }, modifier = Modifier.size(42.dp)) {
                                Icon(
                                    Icons.Filled.CheckCircle, stringResource(R.string.cd_check),
                                    tint = if (supportsCheck(spec.lang)) Color(0xFF5FD38D) else Color(0xFF666666)
                                )
                            }
                            if (runKind != RunKind.NONE) {
                                IconButton(
                                    onClick = { preview = buildPreview(ctx, file, tfv.text, runKind) },
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Icon(
                                        when (runKind) {
                                            RunKind.HTML -> Icons.Filled.Language
                                            RunKind.MD -> Icons.Filled.Visibility
                                            else -> Icons.Filled.PlayArrow
                                        },
                                        stringResource(R.string.cd_run), tint = cs.primary
                                    )
                                }
                            }
                            IconButton(onClick = { save() }, enabled = dirty, modifier = Modifier.size(42.dp)) {
                                Icon(
                                    Icons.Filled.Save, stringResource(R.string.save),
                                    tint = if (dirty) Color.White else Color(0xFF666666)
                                )
                            }
                            Box {
                                IconButton(onClick = { menu = true }, modifier = Modifier.size(42.dp)) {
                                    Icon(Icons.Filled.MoreVert, stringResource(R.string.more))
                                }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.editor_zoom_in)) },
                                        onClick = { menu = false; fontSp = (fontSp + 1f).coerceAtMost(28f) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.editor_zoom_out)) },
                                        onClick = { menu = false; fontSp = (fontSp - 1f).coerceAtLeast(8f) }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                stringResource(
                                                    if (wrap) R.string.editor_wrap_on else R.string.editor_wrap_off
                                                )
                                            )
                                        },
                                        onClick = { menu = false; wrap = !wrap }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.editor_goto)) },
                                        onClick = { menu = false; gotoOpen = true }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.act_open_with)) },
                                        onClick = { menu = false; vm.openWith(ctx, file, true) }
                                    )
                                }
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().background(Color(0xFF26282B)).padding(horizontal = 12.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                file.name + if (dirty) " •" else "", fontSize = 13.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            Text(
                                "${cursorLine + 1}:$cursorCol   UTF-8", fontSize = 12.sp,
                                color = Color(0xFFB0B3B8)
                            )
                        }
                    }
                }

                // ── area teks ──
                Box(
                    Modifier.weight(1f).fillMaxWidth().background(EditorBg)
                        .onSizeChanged { viewportH = it.height }
                ) {
                    if (saved == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = cs.primary)
                        }
                    } else {
                        val viewportDp = with(density) { viewportH.toDp() }
                        Row(
                            Modifier.verticalScroll(vscroll).fillMaxWidth().heightIn(min = viewportDp)
                                .padding(top = padTopDp, bottom = 140.dp)
                        ) {
                            Canvas(Modifier.width(gutterW).height(contentH).background(GutterBg)) {
                                val l = layout
                                if (l != null) {
                                    drawGutter(l, lineStarts, numPaint, gutterWpx - 8.dp.toPx(), vscroll.value, viewportH, padTopPx, result)
                                }
                            }
                            Box(
                                Modifier.weight(1f).then(
                                    if (wrap) Modifier else Modifier.horizontalScroll(hscroll)
                                )
                            ) {
                                BasicTextField(
                                    value = tfv,
                                    onValueChange = { handleChange(it) },
                                    textStyle = style,
                                    cursorBrush = SolidColor(cs.primary),
                                    visualTransformation = transform,
                                    onTextLayout = { layout = it },
                                    modifier = Modifier
                                        .then(if (wrap) Modifier.fillMaxWidth() else Modifier)
                                        .heightIn(min = contentH)
                                        .padding(start = 8.dp, end = 8.dp)
                                        .drawBehind {
                                            val l = layout
                                            if (l != null) {
                                                drawDecor(
                                                    l, lineStarts, guides, charPx, vscroll.value, viewportH,
                                                    padTopPx, tfv.selection.start, result
                                                )
                                            }
                                        }
                                )
                            }
                        }
                    }
                }

                // ── hasil pemeriksaan ──
                val res = result
                if (res != null) {
                    val firstErr = res.errors.entries.firstOrNull()
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (firstErr == null) Color(0xFF1F3D2B) else Color(0xFF4A1F1F))
                            .clickable { if (firstErr != null) jumpToLine(firstErr.key) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (firstErr == null) {
                            Text(stringResource(R.string.check_ok), color = Color(0xFF8FE8B3), fontSize = 13.sp)
                        } else {
                            val msg = stringResource(firstErr.value.resId, firstErr.value.arg)
                            val more = if (res.errors.size > 1) " " + stringResource(R.string.check_more, res.errors.size - 1) else ""
                            Text(
                                stringResource(R.string.check_line, firstErr.key + 1, msg) + more,
                                color = Color(0xFFFFB4B4), fontSize = 13.sp, maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // ── bar simbol ──
                Row(
                    Modifier.fillMaxWidth().background(BarBg).horizontalScroll(rememberScrollState())
                ) {
                    Box(
                        Modifier.width(48.dp).height(42.dp).clickable { insert(unitStr) },
                        contentAlignment = Alignment.Center
                    ) { Text("→", color = Color.White, fontSize = 18.sp) }
                    symbols.forEach { sym ->
                        Box(
                            Modifier.width(42.dp).height(42.dp).clickable { insert(sym) },
                            contentAlignment = Alignment.Center
                        ) { Text(sym, color = Color.White, fontSize = 18.sp, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
        }
    }

    val pv = preview
    if (pv != null) PreviewDialog(pv) { preview = null }

    if (gotoOpen) {
        AlertDialog(
            onDismissRequest = { gotoOpen = false },
            title = { Text(stringResource(R.string.editor_goto)) },
            text = {
                OutlinedTextField(
                    value = gotoText,
                    onValueChange = { gotoText = it.filter { c -> c.isDigit() }.take(7) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = gotoText.toIntOrNull()
                    gotoOpen = false
                    if (n != null && n >= 1) {
                        val i = (n - 1).coerceAtMost(lineStarts.size - 1)
                        tfv = tfv.copy(selection = TextRange(lineStarts[i]))
                        jumpToLine(i)
                    }
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { gotoOpen = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text(stringResource(R.string.discard_title)) },
            text = { Text(stringResource(R.string.discard_text)) },
            confirmButton = {
                TextButton(onClick = { confirmClose = false; vm.editing = null }) {
                    Text(stringResource(R.string.discard), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClose = false }) { Text(stringResource(R.string.keep_editing)) }
            }
        )
    }
}
