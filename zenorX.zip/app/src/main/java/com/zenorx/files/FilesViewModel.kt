package com.zenorx.files

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Status satu panel (A atau B). */
@Stable
class PanelState(val id: Int, start: File) {
    var path by mutableStateOf(start)
    var items by mutableStateOf<List<FileItem>>(emptyList())
    var selected by mutableStateOf<Set<String>>(emptySet())
    var loading by mutableStateOf(false)
    var unreadable by mutableStateOf(false)
    var resultsMode by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var job: Job? = null
    val back = ArrayList<File>()
    val forward = ArrayList<File>()
}

@Stable
class DragState {
    var active by mutableStateOf(false)
    var from by mutableIntStateOf(0)
    var files by mutableStateOf<List<File>>(emptyList())
    var pos by mutableStateOf(Offset.Zero)
    var start: Offset = Offset.Zero
    var hoverPanel by mutableIntStateOf(-1)
    var hoverFolder by mutableStateOf<String?>(null)
}

class Clip(val files: List<File>, val move: Boolean)
class Busy(val title: String, val detail: String, val done: Int, val total: Int)
class DropReq(val files: List<File>, val dest: File, val from: Int)
class PropsInfo(val file: File, val bytes: Long? = null, val files: Int? = null)
class SheetReq(val item: FileItem, val panel: Int)

class ArchiveOptions(
    val name: String,
    val dest: File,
    /** 0 simpan, 1 tercepat, 2 cepat, 3 normal, 4 maksimum */
    val level: Int,
    val password: String,
    /** 0 ZipCrypto, 1 AES-128, 2 AES-256 */
    val enc: Int,
    val volumeBytes: Long,
    val deleteSource: Boolean,
    val separate: Boolean
)

/** entries == null berarti masih memuat. */
class ArchiveInfo(
    val file: File,
    val entries: List<Pair<String, Long>>?,
    val error: String?,
    val total: Int
)

sealed class Dlg {
    class Rename(val file: File) : Dlg()
    class NewFolder(val dir: File) : Dlg()
    class NewFile(val dir: File) : Dlg()
    class Delete(val files: List<File>) : Dlg()
    class CreateArchive(val files: List<File>, val dir: File) : Dlg()
    class Password(val zip: File, val dest: File, val sub: Boolean) : Dlg()
    class SelfUpdate(val file: File) : Dlg()
    class InstallPerm(val file: File) : Dlg()
    object Prefs : Dlg()
    object ViewOpts : Dlg()
    object About : Dlg()
}

private fun listDir(
    dir: File, hidden: Boolean, by: SortBy, asc: Boolean, grouped: Boolean
): Pair<List<FileItem>, Boolean> {
    val arr = dir.listFiles() ?: return emptyList<FileItem>() to true
    val items = ArrayList<FileItem>(arr.size)
    for (f in arr) {
        if (!hidden && f.name.startsWith(".")) continue
        items.add(makeItem(f))
    }
    return sortItems(items, by, asc, grouped) to false
}

/**
 * Urutan tampilan: Folder, lalu File, lalu Arsip (zip/rar/7z/...) di paling bawah.
 * Bila [grouped] mati, arsip bercampur dengan file biasa (folder tetap di atas).
 */
fun sortItems(list: List<FileItem>, by: SortBy, asc: Boolean, grouped: Boolean): List<FileItem> {
    val base = Comparator<FileItem> { a, b ->
        val c = when (by) {
            SortBy.NAME -> a.name.compareTo(b.name, true)
            SortBy.SIZE -> a.size.compareTo(b.size)
            SortBy.DATE -> a.modified.compareTo(b.modified)
            SortBy.TYPE -> a.file.extension.compareTo(b.file.extension, true)
        }
        if (c != 0) c else a.name.compareTo(b.name, true)
    }
    val cmp = if (asc) base else base.reversed()
    val dirs = list.filter { it.isDir }.sortedWith(cmp)
    if (!grouped) {
        return dirs + list.filter { !it.isDir }.sortedWith(cmp)
    }
    val files = list.filter { !it.isDir && it.kind != FileKind.ARCHIVE }.sortedWith(cmp)
    val archives = list.filter { it.kind == FileKind.ARCHIVE }.sortedWith(cmp)
    return dirs + files + archives
}

@Stable
class FilesViewModel(private val app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("zenorx", Context.MODE_PRIVATE)

    private fun s(id: Int, vararg a: Any): String = app.getString(id, *a)
    val root: File = Environment.getExternalStorageDirectory()
    val sdCards: List<File> = findSdCards()

    // ---- pengaturan ----
    var dual by mutableStateOf(prefs.getBoolean("dual2", false))
        private set
    var showHidden by mutableStateOf(prefs.getBoolean("hidden", false))
        private set
    var dark by mutableStateOf(prefs.getBoolean("dark", true))
        private set
    var sortBy by mutableStateOf(SortBy.values().getOrElse(prefs.getInt("sort", 0)) { SortBy.NAME })
        private set
    var sortAsc by mutableStateOf(prefs.getBoolean("asc", true))
        private set
    var categories by mutableStateOf(prefs.getBoolean("cat", true))
        private set
    var viewMode by mutableStateOf(ViewMode.values().getOrElse(prefs.getInt("view", 0)) { ViewMode.DETAIL })
        private set
    var palette by mutableIntStateOf(prefs.getInt("palette", 0))
        private set
    /** 0 = tanya, 1 = langsung salin, 2 = langsung pindah */
    var dropMode by mutableIntStateOf(prefs.getInt("drop", 0))
        private set

    // ---- panel ----
    val panelA = PanelState(0, startDir("pathA"))
    val panelB = PanelState(1, startDir("pathB"))
    var active by mutableIntStateOf(0)

    var clip by mutableStateOf<Clip?>(null)
    var busy by mutableStateOf<Busy?>(null)
        private set
    var dlg by mutableStateOf<Dlg?>(null)
    var props by mutableStateOf<PropsInfo?>(null)
        private set
    var dropReq by mutableStateOf<DropReq?>(null)
    var editing by mutableStateOf<File?>(null)
    var sheet by mutableStateOf<SheetReq?>(null)
    var archive by mutableStateOf<ArchiveInfo?>(null)
    var searchOpen by mutableStateOf(false)
    var searchText by mutableStateOf("")
    var fabOpen by mutableStateOf(false)
    var multi by mutableStateOf(false)

    val dnd = DragState()
    val panelBounds = HashMap<Int, Rect>()
    val hitTesters = HashMap<Int, (Offset) -> String?>()

    val messages = Channel<String>(Channel.BUFFERED)
    private var opJob: Job? = null
    private var propsJob: Job? = null

    init {
        load(panelA)
        load(panelB)
    }

    private fun startDir(key: String): File {
        val s = prefs.getString(key, null)
        if (s != null) {
            val f = File(s)
            if (f.isDirectory) return f
        }
        return root
    }

    private fun findSdCards(): List<File> {
        val res = ArrayList<File>()
        try {
            app.getExternalFilesDirs(null).drop(1).forEach { f ->
                if (f == null) return@forEach
                val s = f.absolutePath
                val i = s.indexOf("/Android/data")
                if (i > 0) {
                    val r = File(s.substring(0, i))
                    if (r.exists() && r.canRead()) res.add(r)
                }
            }
        } catch (e: Exception) {
        }
        return res
    }

    fun panel(i: Int): PanelState = if (i == 0) panelA else panelB
    fun activate(p: PanelState) {
        active = p.id
    }

    fun toast(s: String) {
        messages.trySend(s)
    }

    // ---- pengaturan ----
    fun changeDual(v: Boolean) {
        dual = v
        prefs.edit().putBoolean("dual2", v).apply()
        if (!v) active = 0
        fabOpen = false
    }

    fun changeHidden(v: Boolean) {
        showHidden = v
        prefs.edit().putBoolean("hidden", v).apply()
        refreshAll()
    }

    fun changeDark(v: Boolean) {
        dark = v
        prefs.edit().putBoolean("dark", v).apply()
    }

    fun changeSort(by: SortBy, asc: Boolean) {
        sortBy = by
        sortAsc = asc
        prefs.edit().putInt("sort", by.ordinal).putBoolean("asc", asc).apply()
        refreshAll()
    }

    fun changeCategories(v: Boolean) {
        categories = v
        prefs.edit().putBoolean("cat", v).apply()
        refreshAll()
    }

    fun changeViewMode(m: ViewMode) {
        viewMode = m
        prefs.edit().putInt("view", m.ordinal).apply()
    }

    fun changePalette(i: Int) {
        palette = i
        prefs.edit().putInt("palette", i).apply()
    }

    fun changeDropMode(v: Int) {
        dropMode = v
        prefs.edit().putInt("drop", v).apply()
    }

    // ---- navigasi ----
    fun crumbs(f: File): List<Pair<String, File>> {
        val list = ArrayList<Pair<String, File>>()
        var cur: File? = f
        while (cur != null) {
            if (cur == root) {
                list.add(s(R.string.storage_internal) to cur)
                break
            }
            list.add((if (cur.parentFile == null) "/" else cur.name) to cur)
            cur = cur.parentFile
        }
        return list.reversed()
    }

    fun canGoUp(p: PanelState): Boolean =
        p.resultsMode || (p.path != root && p.path.parentFile != null)

    private fun canEnter(dir: File): Boolean {
        if (!dir.isDirectory) {
            toast(s(R.string.t_folder_not_found))
            return false
        }
        if (!dir.canRead()) {
            toast(s(R.string.t_no_read_permission, dir.name.ifEmpty { "/" }))
            return false
        }
        return true
    }

    private fun syncNav(p: PanelState) {
        p.canBack = p.back.isNotEmpty()
        p.canForward = p.forward.isNotEmpty()
    }

    private fun enter(p: PanelState, dir: File) {
        p.path = dir
        p.selected = emptySet()
        syncNav(p)
        load(p)
        prefs.edit().putString(if (p.id == 0) "pathA" else "pathB", dir.absolutePath).apply()
    }

    fun navigate(p: PanelState, dir: File) {
        if (!canEnter(dir)) return
        fabOpen = false
        if (p.path != dir) {
            p.back.add(p.path)
            if (p.back.size > 60) p.back.removeAt(0)
            p.forward.clear()
        }
        enter(p, dir)
    }

    fun goBack(p: PanelState) {
        active = p.id
        if (p.back.isEmpty()) return
        val d = p.back[p.back.size - 1]
        if (!canEnter(d)) {
            p.back.removeAt(p.back.size - 1)
            syncNav(p)
            return
        }
        p.back.removeAt(p.back.size - 1)
        p.forward.add(p.path)
        enter(p, d)
    }

    fun goForward(p: PanelState) {
        active = p.id
        if (p.forward.isEmpty()) return
        val d = p.forward[p.forward.size - 1]
        if (!canEnter(d)) {
            p.forward.removeAt(p.forward.size - 1)
            syncNav(p)
            return
        }
        p.forward.removeAt(p.forward.size - 1)
        p.back.add(p.path)
        enter(p, d)
    }

    fun up(p: PanelState) {
        active = p.id
        if (p.resultsMode) {
            load(p)
            return
        }
        val parent = p.path.parentFile ?: return
        navigate(p, parent)
    }

    fun swapPanels() {
        val a = panelA.path
        val b = panelB.path
        navigate(panelA, b)
        navigate(panelB, a)
    }

    fun syncPanels() {
        val src = panel(active)
        val dst = panel(1 - active)
        navigate(dst, src.path)
    }

    fun load(p: PanelState) {
        p.job?.cancel()
        p.loading = true
        p.resultsMode = false
        val dir = p.path
        val hidden = showHidden
        val by = sortBy
        val asc = sortAsc
        val grouped = categories
        p.job = viewModelScope.launch {
            val res = withContext(Dispatchers.IO) { listDir(dir, hidden, by, asc, grouped) }
            if (p.path == dir) {
                p.items = res.first
                p.unreadable = res.second
                val existing = res.first.mapTo(HashSet()) { it.path }
                p.selected = p.selected.filterTo(HashSet()) { it in existing }
            }
            p.loading = false
        }
    }

    fun refreshAll() {
        load(panelA)
        load(panelB)
    }

    // ---- pencarian ----
    fun toggleSearch() {
        if (searchOpen) closeSearch() else searchOpen = true
    }

    fun closeSearch() {
        searchOpen = false
        searchText = ""
        val p = panel(active)
        if (p.resultsMode) load(p)
    }

    fun search(p: PanelState, q: String) {
        if (q.isBlank()) {
            if (p.resultsMode) load(p)
            return
        }
        p.job?.cancel()
        p.loading = true
        p.resultsMode = true
        p.selected = emptySet()
        val root0 = p.path
        val hidden = showHidden
        val by = sortBy
        val asc = sortAsc
        val needle = q.trim()
        val grouped = categories
        p.job = viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                val out = ArrayList<FileItem>()
                val stack = ArrayList<File>()
                stack.add(root0)
                while (stack.isNotEmpty() && out.size < 500) {
                    ensureActive()
                    val d = stack.removeAt(stack.size - 1)
                    val kids = d.listFiles() ?: continue
                    for (f in kids) {
                        if (!hidden && f.name.startsWith(".")) continue
                        if (f.name.contains(needle, ignoreCase = true)) out.add(makeItem(f))
                        if (f.isDirectory && !FileOps.isLink(f)) stack.add(f)
                    }
                }
                sortItems(out, by, asc, grouped)
            }
            p.items = res
            p.unreadable = false
            p.loading = false
        }
    }

    // ---- seleksi ----
    fun selecting(): Boolean =
        multi || panelA.selected.isNotEmpty() || panelB.selected.isNotEmpty()

    fun clearSelection() {
        panelA.selected = emptySet()
        panelB.selected = emptySet()
        multi = false
    }

    fun selectedFiles(p: PanelState): List<File> =
        if (p.selected.isEmpty()) emptyList() else p.items.filter { it.path in p.selected }.map { it.file }

    fun toggle(p: PanelState, item: FileItem) {
        val other = panel(1 - p.id)
        if (other.selected.isNotEmpty()) other.selected = emptySet()
        p.selected = if (item.path in p.selected) p.selected - item.path else p.selected + item.path
    }

    fun selectAll(p: PanelState) {
        p.selected = p.items.mapTo(HashSet()) { it.path }
    }

    fun onRowTap(p: PanelState, path: String, ctx: Context) {
        active = p.id
        fabOpen = false
        val item = p.items.firstOrNull { it.path == path } ?: return
        if (selecting()) {
            toggle(p, item)
            return
        }
        if (item.isDir) navigate(p, item.file) else sheet = SheetReq(item, p.id)
    }

    // ---- buka / bagikan / instal ----
    private fun uriOf(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)

    fun openWith(ctx: Context, f: File, chooser: Boolean) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriOf(ctx, f), mimeOf(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(if (chooser) Intent.createChooser(i, s(R.string.act_open_with)) else i)
        } catch (e: Exception) {
            toast(s(R.string.t_no_app_to_open))
        }
    }

    fun installApk(ctx: Context, f: File) {
        val own = try {
            ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0)?.packageName == ctx.packageName
        } catch (e: Exception) {
            false
        }
        if (own) dlg = Dlg.SelfUpdate(f) else proceedInstall(ctx, f)
    }

    fun proceedInstall(ctx: Context, f: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !ctx.packageManager.canRequestPackageInstalls()) {
            dlg = Dlg.InstallPerm(f)
            return
        }
        openWith(ctx, f, false)
    }

    /** Android biasanya me-restart aplikasi setelah izin pasang aplikasi diberikan, jadi instal dilanjutkan otomatis. */
    fun openInstallSettings(ctx: Context, f: File) {
        prefs.edit().putString("pending_apk", f.absolutePath).apply()
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            )
        } catch (e: Exception) {
            toast(s(R.string.t_no_app_to_open))
        }
    }

    fun resumePendingInstall(ctx: Context) {
        val path = prefs.getString("pending_apk", null) ?: return
        prefs.edit().remove("pending_apk").apply()
        val f = File(path)
        if (!f.exists()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !ctx.packageManager.canRequestPackageInstalls()) return
        openWith(ctx, f, false)
    }

    fun share(ctx: Context, files: List<File>) {
        val only = files.filter { it.isFile }
        if (only.isEmpty()) {
            toast(s(R.string.t_select_files_share))
            return
        }
        try {
            val uris = ArrayList<Uri>(only.map { uriOf(ctx, it) })
            val i = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0]).setType(mimeOf(only[0]))
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris).setType("*/*")
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, s(R.string.share)))
        } catch (e: Exception) {
            toast(s(R.string.t_share_failed, e.message ?: ""))
        }
    }

    // ---- drag & drop ----
    fun dragStart(p: PanelState, path: String, pos: Offset) {
        active = p.id
        fabOpen = false
        val other = panel(1 - p.id)
        if (other.selected.isNotEmpty()) other.selected = emptySet()
        if (path !in p.selected) p.selected = p.selected + path
        multi = true
        dnd.from = p.id
        dnd.files = selectedFiles(p)
        dnd.start = pos
        dnd.pos = pos
        dnd.active = true
        updateHover()
    }

    fun dragMove(pos: Offset) {
        if (!dnd.active) return
        dnd.pos = pos
        updateHover()
    }

    fun dragCancel() {
        dnd.active = false
        dnd.hoverFolder = null
        dnd.hoverPanel = -1
    }

    fun dragEnd() {
        if (!dnd.active) return
        val files = dnd.files
        val from = dnd.from
        val moved = (dnd.pos - dnd.start).getDistance() > 36f
        val hp = dnd.hoverPanel
        val hf = dnd.hoverFolder
        val dest: File? = when {
            hp < 0 -> null
            hf == ".." -> if (panel(hp).resultsMode) null else panel(hp).path.parentFile
            hf != null -> File(hf)
            hp == from -> null
            else -> panel(hp).path
        }
        dragCancel()
        if (!moved || dest == null || files.isEmpty()) return
        when (dropMode) {
            1 -> {
                clearSelection()
                transfer(files, dest, false)
            }
            2 -> {
                clearSelection()
                transfer(files, dest, true)
            }
            else -> dropReq = DropReq(files, dest, from)
        }
    }

    private fun updateHover() {
        val pos = dnd.pos
        var pid = -1
        for ((id, r) in panelBounds) {
            if (r.contains(pos) && (id == 0 || dual)) {
                pid = id
                break
            }
        }
        var folder: String? = null
        if (pid >= 0) {
            val key = hitTesters[pid]?.invoke(pos)
            if (key != null) {
                if (key == "..") {
                    folder = ".."
                } else {
                    val isDragged = dnd.files.any { it.absolutePath == key }
                    if (!isDragged && panel(pid).items.any { it.isDir && it.path == key }) folder = key
                }
            }
        }
        dnd.hoverPanel = pid
        dnd.hoverFolder = folder
    }

    // ---- operasi file ----
    inner class Progress(private val title: String) {
        @Volatile private var total = 1
        @Volatile private var done = 0
        private var last = 0L

        fun begin(n: Int) {
            total = if (n < 1) 1 else n
            busy = Busy(title, "", done, total)
        }

        fun step(name: String) {
            done++
            val now = SystemClock.uptimeMillis()
            if (now - last > 80 || done >= total) {
                last = now
                busy = Busy(title, name, done, total)
            }
        }
    }

    private fun runOp(title: String, ok: String, block: suspend (Progress) -> Unit) {
        val pr = Progress(title)
        busy = Busy(title, "", 0, 1)
        opJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { block(pr) }
                toast(ok)
            } catch (e: CancellationException) {
                toast(s(R.string.t_cancelled))
            } catch (e: Exception) {
                toast(s(R.string.t_failed, e.message ?: e.javaClass.simpleName))
            } finally {
                busy = null
                refreshAll()
            }
        }
    }

    fun cancelOp() {
        opJob?.cancel()
    }

    private fun isBusy(): Boolean {
        if (busy != null) {
            toast(s(R.string.t_still_running))
            return true
        }
        return false
    }

    fun putClip(files: List<File>, move: Boolean) {
        if (files.isEmpty()) return
        clip = Clip(files, move)
        toast(s(if (move) R.string.t_clip_cut else R.string.t_clip_copied, files.size))
    }

    fun copyToClip(p: PanelState, move: Boolean) {
        putClip(selectedFiles(p), move)
        clearSelection()
    }

    fun paste(p: PanelState) {
        val c = clip ?: return
        transfer(c.files, p.path, c.move)
        if (c.move) clip = null
    }

    fun transfer(files: List<File>, dest: File, move: Boolean) {
        if (isBusy()) return
        if (!dest.isDirectory || !dest.canWrite()) {
            toast(s(R.string.t_dest_not_writable))
            return
        }
        val destPath = try { dest.canonicalPath } catch (e: Exception) { dest.absolutePath }
        val valid = files.filter { f ->
            if (!f.exists()) return@filter false
            val fp = try { f.canonicalPath } catch (e: Exception) { f.absolutePath }
            val inside = f.isDirectory && (destPath == fp || destPath.startsWith(fp + File.separator))
            val same = move && f.parentFile?.absolutePath == dest.absolutePath
            !inside && !same
        }
        if (valid.isEmpty()) {
            toast(s(R.string.t_nothing_to_process))
            return
        }
        runOp(s(if (move) R.string.op_moving else R.string.op_copying), s(if (move) R.string.done_moved else R.string.done_copied)) { p ->
            p.begin(valid.sumOf { FileOps.countFiles(it) })
            for (f in valid) {
                if (move) FileOps.move(f, dest) { n -> p.step(n) } else FileOps.copy(f, dest) { n -> p.step(n) }
            }
        }
    }

    fun transferToOther(move: Boolean) {
        if (!dual) return
        val src = panel(active)
        val files = selectedFiles(src)
        if (files.isEmpty()) {
            toast(s(R.string.t_pick_files_first))
            return
        }
        clearSelection()
        transfer(files, panel(1 - active).path, move)
    }

    fun delete(files: List<File>) {
        if (isBusy()) return
        clearSelection()
        runOp(s(R.string.op_deleting), s(R.string.done_deleted)) { p ->
            p.begin(files.sumOf { FileOps.countFiles(it) })
            for (f in files) FileOps.delete(f) { n -> p.step(n) }
        }
    }

    /** Kompres cepat ke *.zip (level normal, tanpa sandi). */
    fun compress(files: List<File>, dir: File) {
        if (isBusy() || files.isEmpty()) return
        clearSelection()
        val baseName = if (files.size == 1) {
            val f = files[0]
            if (f.isDirectory) f.name else f.nameWithoutExtension
        } else {
            dir.name.ifEmpty { "archive" }
        }
        val out = FileOps.uniqueTarget(dir, "$baseName.zip")
        runOp(s(R.string.op_compressing), s(R.string.done_created, out.name)) { p ->
            p.begin(files.sumOf { FileOps.countFiles(it) })
            try {
                FileOps.zip(files, out, FileOps.javaLevel(3)) { n -> p.step(n) }
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        }
    }

    /** Dialog "Buat Arsip": nama, level, sandi + enkripsi, volume, hapus sumber, arsip terpisah. */
    fun createArchive(files: List<File>, opt: ArchiveOptions) {
        if (isBusy() || files.isEmpty()) return
        if (!opt.dest.isDirectory || !opt.dest.canWrite()) {
            toast(s(R.string.t_dest_not_writable))
            return
        }
        clearSelection()
        var base = opt.name.trim()
        if (base.isEmpty()) base = "archive"
        if (!base.endsWith(".zip", ignoreCase = true)) base += ".zip"
        val jobs = ArrayList<Pair<List<File>, String>>()
        if (opt.separate) {
            for (f in files) jobs.add(listOf(f) to ((if (f.isDirectory) f.name else f.nameWithoutExtension) + ".zip"))
        } else {
            jobs.add(files to base)
        }
        val encrypted = opt.password.isNotEmpty()
        runOp(s(R.string.op_compressing), s(R.string.done_archive)) { p ->
            p.begin(if (encrypted) files.size else files.sumOf { FileOps.countFiles(it) })
            for ((group, name) in jobs) {
                val out = FileOps.uniqueTarget(opt.dest, name)
                try {
                    if (encrypted) {
                        FileOps.zipEncrypted(group, out, opt.password, opt.level, opt.enc) { n -> p.step(n) }
                    } else {
                        FileOps.zip(group, out, FileOps.javaLevel(opt.level)) { n -> p.step(n) }
                    }
                    if (opt.volumeBytes > 0) FileOps.splitFile(out, opt.volumeBytes)
                } catch (e: Throwable) {
                    out.delete()
                    FileOps.deleteParts(out)
                    throw e
                }
            }
            if (opt.deleteSource) {
                for (f in files) FileOps.delete(f) { }
            }
        }
    }

    private fun extractInternal(zip: File, dir: File, sub: Boolean) {
        if (isBusy()) return
        viewModelScope.launch {
            val enc = withContext(Dispatchers.IO) { FileOps.isEncrypted(zip) }
            if (enc) {
                dlg = Dlg.Password(zip, dir, sub)
                return@launch
            }
            clearSelection()
            runOp(s(R.string.op_extracting), s(R.string.done_extracted)) { p ->
                p.begin(FileOps.zipCount(zip))
                FileOps.unzip(zip, dir, sub) { n -> p.step(n) }
            }
        }
    }

    fun extractFolder(zip: File, dir: File) = extractInternal(zip, dir, true)
    fun extractHere(zip: File, dir: File) = extractInternal(zip, dir, false)

    fun extractEncrypted(zip: File, dir: File, sub: Boolean, password: String) {
        if (isBusy()) return
        clearSelection()
        runOp(s(R.string.op_extracting), s(R.string.done_extracted)) { p ->
            p.begin(FileOps.headerCount(zip))
            FileOps.unzipEncrypted(zip, dir, sub, password) { n -> p.step(n) }
        }
    }

    fun testArchive(zip: File) {
        if (isBusy()) return
        viewModelScope.launch {
            val enc = withContext(Dispatchers.IO) { FileOps.isEncrypted(zip) }
            if (enc) {
                toast(s(R.string.t_encrypted_use_extract))
                return@launch
            }
            runOp(s(R.string.op_testing), s(R.string.done_test_ok)) { p ->
                p.begin(FileOps.zipCount(zip))
                FileOps.testZip(zip) { n -> p.step(n) }
            }
        }
    }

    /** Gabungkan nama.zip.001, .002, ... menjadi satu zip. */
    fun joinVolumes(first: File) {
        if (isBusy()) return
        val dir = first.parentFile ?: return
        val out = FileOps.uniqueTarget(dir, first.name.removeSuffix(".001"))
        runOp(s(R.string.op_merging), s(R.string.done_created, out.name)) { p ->
            p.begin(FileOps.countParts(first))
            try {
                FileOps.joinParts(first, out) { n -> p.step(n) }
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        }
    }

    fun viewArchive(f: File) {
        archive = ArchiveInfo(f, null, null, 0)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                try { FileOps.listZip(f, 3000) } catch (e: Exception) { null }
            }
            if (archive?.file == f) {
                archive = if (r == null) {
                    ArchiveInfo(f, emptyList(), s(R.string.t_archive_unreadable), 0)
                } else {
                    ArchiveInfo(f, r.first, null, r.second)
                }
            }
        }
    }

    private fun validName(n: String): Boolean =
        n.isNotBlank() && !n.contains('/') && n != "." && n != ".."

    fun rename(f: File, newName: String) {
        val n = newName.trim()
        if (!validName(n)) {
            toast(s(R.string.t_invalid_name))
            return
        }
        val target = File(f.parentFile, n)
        if (target.exists() && target.absolutePath != f.absolutePath) {
            toast(s(R.string.t_exists, n))
            return
        }
        if (f.renameTo(target)) {
            clearSelection()
            toast(s(R.string.t_renamed))
            refreshAll()
        } else {
            toast(s(R.string.t_rename_failed))
        }
    }

    fun createFolder(dir: File, name: String) {
        val n = name.trim()
        if (!validName(n)) {
            toast(s(R.string.t_invalid_name))
            return
        }
        val f = File(dir, n)
        if (f.exists()) {
            toast(s(R.string.t_exists, n))
            return
        }
        if (f.mkdirs()) {
            toast(s(R.string.t_folder_created))
            refreshAll()
        } else {
            toast(s(R.string.t_folder_failed))
        }
    }

    fun createFile(dir: File, name: String) {
        val n = name.trim()
        if (!validName(n)) {
            toast(s(R.string.t_invalid_name))
            return
        }
        val f = File(dir, n)
        if (f.exists()) {
            toast(s(R.string.t_exists, n))
            return
        }
        try {
            if (f.createNewFile()) {
                toast(s(R.string.t_file_created))
                refreshAll()
            } else {
                toast(s(R.string.t_file_failed))
            }
        } catch (e: Exception) {
            toast(s(R.string.t_file_failed_msg, e.message ?: ""))
        }
    }

    fun showProps(f: File) {
        propsJob?.cancel()
        props = PropsInfo(f)
        propsJob = viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { FileOps.measure(f) }
            if (props?.file == f) props = PropsInfo(f, r.first, r.second)
        }
    }

    fun closeProps() {
        propsJob?.cancel()
        props = null
    }
}
