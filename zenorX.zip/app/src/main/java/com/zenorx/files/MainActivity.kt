package com.zenorx.files

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vm: FilesViewModel by viewModels()
    private var granted by mutableStateOf(false)
    private var crash by mutableStateOf<String?>(null)

    private val legacyPerm = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { onAccessChanged() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        crash = CrashLog.read(this)
        granted = hasAccess()
        setContent {
            ZenorXTheme(dark = vm.dark, palette = vm.palette) {
                if (granted) ZenorXApp(vm) else PermissionScreen(onGrant = { askAccess() })
                val report = crash
                if (report != null) {
                    CrashDialog(report) {
                        CrashLog.clear(this@MainActivity)
                        crash = null
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        onAccessChanged()
        if (granted) vm.resumePendingInstall(this)
        requestHighRefreshRate()
    }

    /** Minta layar memakai refresh rate tertinggi (90/120 Hz) supaya scroll mulus. */
    private fun requestHighRefreshRate() {
        try {
            @Suppress("DEPRECATION")
            val disp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else windowManager.defaultDisplay
            if (disp == null) return
            val cur = disp.mode
            var best = cur
            for (m in disp.supportedModes) {
                if (m.physicalWidth == cur.physicalWidth && m.physicalHeight == cur.physicalHeight &&
                    m.refreshRate > best.refreshRate
                ) {
                    best = m
                }
            }
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (e: Exception) {
        }
    }

    private fun onAccessChanged() {
        val g = hasAccess()
        if (g && !granted) {
            granted = true
            vm.refreshAll()
        } else {
            granted = g
        }
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }
}
