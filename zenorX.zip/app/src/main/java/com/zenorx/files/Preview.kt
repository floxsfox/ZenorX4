package com.zenorx.files

import android.content.Context
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONObject
import java.io.File

enum class RunKind { NONE, HTML, JS, PYTHON, MD }

class PreviewReq(val title: String, val html: String, val baseUrl: String?)

fun runKindOf(l: Lang, ext: String): RunKind = when (l) {
    Lang.HTML -> RunKind.HTML
    Lang.JS -> if (ext == "js" || ext == "mjs" || ext == "cjs") RunKind.JS else RunKind.NONE
    Lang.PYTHON -> RunKind.PYTHON
    Lang.MD -> RunKind.MD
    else -> RunKind.NONE
}

private fun jsLiteral(s: String): String = JSONObject.quote(s).replace("</", "<\\/")

private const val CONSOLE_STYLE =
    "<style>body{background:#1e1f22;color:#d7d7d7;font:13px/1.5 monospace;margin:0;padding:12px}" +
        "pre{white-space:pre-wrap;word-break:break-word;margin:0}.e{color:#ff6b6b}.i{color:#8ab4f8}</style>"

private const val CONSOLE_FN =
    "var o=document.getElementById('o');" +
        "function w(t,c){var s=document.createElement('span');if(c)s.className=c;s.textContent=t+'\\n';o.appendChild(s);}" +
        "function fmt(a){return Array.prototype.map.call(a,function(x){try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(' ');}"

private fun jsRunnerHtml(code: String): String =
    "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
        CONSOLE_STYLE + "</head><body><pre id=\"o\"></pre><script>" + CONSOLE_FN +
        "console.log=function(){w(fmt(arguments))};console.info=function(){w(fmt(arguments),'i')};" +
        "console.warn=function(){w(fmt(arguments),'i')};console.error=function(){w(fmt(arguments),'e')};" +
        "window.onerror=function(m,s,l){w('Error: '+m+(l?' (line '+l+')':''),'e');return true;};" +
        "try{(0,eval)(" + jsLiteral(code) + ");}catch(e){w(String(e),'e');}" +
        "</script></body></html>"

private fun pyRunnerHtml(code: String, loading: String, done: String): String =
    "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
        CONSOLE_STYLE +
        "<script src=\"https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js\"></script></head>" +
        "<body><pre id=\"o\"></pre><script>" + CONSOLE_FN +
        "async function main(){w(" + jsLiteral(loading) + ",'i');" +
        "try{var py=await loadPyodide();" +
        "py.setStdout({batched:function(s){w(s)}});py.setStderr({batched:function(s){w(s,'e')}});" +
        "await py.runPythonAsync(" + jsLiteral(code) + ");w(" + jsLiteral(done) + ",'i');" +
        "}catch(e){w(String(e),'e');}}main();</script></body></html>"

private fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

private fun inlineMd(s0: String): String {
    var s = esc(s0)
    s = Regex("`([^`]+)`").replace(s) { "<code>" + it.groupValues[1] + "</code>" }
    s = Regex("\\*\\*([^*]+)\\*\\*").replace(s) { "<b>" + it.groupValues[1] + "</b>" }
    s = Regex("\\*([^*]+)\\*").replace(s) { "<i>" + it.groupValues[1] + "</i>" }
    s = Regex("\\[([^\\]]+)\\]\\(([^)]+)\\)").replace(s) {
        "<a href=\"" + it.groupValues[2] + "\">" + it.groupValues[1] + "</a>"
    }
    return s
}

private fun mdToHtml(md: String): String {
    val sb = StringBuilder()
    sb.append("<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
    sb.append("<style>body{font:15px/1.6 sans-serif;margin:0;padding:14px;color:#222;background:#fff}")
    sb.append("code{background:#eee;padding:1px 4px;border-radius:4px}pre{background:#f4f4f4;padding:10px;border-radius:6px;overflow:auto}")
    sb.append("blockquote{border-left:4px solid #ccc;margin:8px 0;padding:2px 12px;color:#555}h1,h2{border-bottom:1px solid #ddd}")
    sb.append("a{color:#0b6bcb}</style></head><body>")
    var inCode = false
    var inList = false
    var para = StringBuilder()
    fun flushPara() {
        if (para.isNotEmpty()) {
            sb.append("<p>").append(para.toString().trim()).append("</p>")
            para = StringBuilder()
        }
    }
    fun closeList() {
        if (inList) {
            sb.append("</ul>")
            inList = false
        }
    }
    for (raw in md.split("\n")) {
        val line = raw.trimEnd('\r')
        if (line.trimStart().startsWith("```")) {
            flushPara()
            closeList()
            sb.append(if (inCode) "</pre>" else "<pre>")
            inCode = !inCode
            continue
        }
        if (inCode) {
            sb.append(esc(line)).append("\n")
            continue
        }
        val t = line.trim()
        if (t.isEmpty()) {
            flushPara()
            closeList()
            continue
        }
        val hashes = t.takeWhile { it == '#' }.length
        if (hashes in 1..6 && t.length > hashes && t[hashes] == ' ') {
            flushPara()
            closeList()
            sb.append("<h$hashes>").append(inlineMd(t.substring(hashes + 1))).append("</h$hashes>")
        } else if (t == "---" || t == "***") {
            flushPara()
            closeList()
            sb.append("<hr>")
        } else if (t.startsWith("> ")) {
            flushPara()
            closeList()
            sb.append("<blockquote>").append(inlineMd(t.substring(2))).append("</blockquote>")
        } else if (t.startsWith("- ") || t.startsWith("* ") || Regex("^\\d+\\. .*").matches(t)) {
            flushPara()
            if (!inList) {
                sb.append("<ul>")
                inList = true
            }
            val body = if (t.startsWith("- ") || t.startsWith("* ")) t.substring(2) else t.substringAfter(". ")
            sb.append("<li>").append(inlineMd(body)).append("</li>")
        } else {
            closeList()
            para.append(inlineMd(t)).append(' ')
        }
    }
    flushPara()
    closeList()
    if (inCode) sb.append("</pre>")
    sb.append("</body></html>")
    return sb.toString()
}

fun buildPreview(ctx: Context, file: File, text: String, kind: RunKind): PreviewReq {
    val base = "file://" + (file.parent ?: "") + "/"
    return when (kind) {
        RunKind.HTML -> PreviewReq(file.name, text, base)
        RunKind.JS -> PreviewReq(file.name, jsRunnerHtml(text), "https://zenorx.local/")
        RunKind.PYTHON -> PreviewReq(
            file.name,
            pyRunnerHtml(text, ctx.getString(R.string.py_loading), ctx.getString(R.string.py_done)),
            "https://zenorx.local/"
        )
        RunKind.MD -> PreviewReq(file.name, mdToHtml(text), base)
        RunKind.NONE -> PreviewReq(file.name, "", null)
    }
}

@Composable
fun PreviewDialog(req: PreviewReq, onClose: () -> Unit) {
    val holder = remember { arrayOfNulls<WebView>(1) }
    DisposableEffect(Unit) {
        onDispose {
            try {
                holder[0]?.destroy()
            } catch (e: Exception) {
            }
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column {
                Row(
                    Modifier.fillMaxWidth().background(LocalToolbar.current).height(52.dp).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, stringResource(R.string.close), tint = Color.White)
                    }
                    Text(
                        req.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        holder[0]?.loadDataWithBaseURL(req.baseUrl, req.html, "text/html", "UTF-8", null)
                    }) {
                        Icon(Icons.Filled.Refresh, stringResource(R.string.cd_refresh), tint = Color.White)
                    }
                }
                AndroidView(
                    factory = { c ->
                        WebView(c).also { wv ->
                            holder[0] = wv
                            wv.settings.javaScriptEnabled = true
                            wv.settings.domStorageEnabled = true
                            wv.settings.allowFileAccess = true
                            wv.settings.setAllowFileAccessFromFileURLs(true)
                            wv.settings.setAllowUniversalAccessFromFileURLs(true)
                            wv.webViewClient = WebViewClient()
                            wv.webChromeClient = WebChromeClient()
                            wv.loadDataWithBaseURL(req.baseUrl, req.html, "text/html", "UTF-8", null)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
