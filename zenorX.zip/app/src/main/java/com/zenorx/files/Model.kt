package com.zenorx.files

import android.os.StatFs
import android.webkit.MimeTypeMap
import androidx.compose.runtime.Immutable
import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SortBy {
    NAME, SIZE, DATE, TYPE
}

enum class ViewMode { DETAIL, COMPACT, GRID }

enum class FileKind { FOLDER, IMAGE, AUDIO, VIDEO, ARCHIVE, APK, CODE, PDF, TEXT, OTHER }

@Immutable
class FileItem(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: FileKind
) {
    val name: String = file.name
    val path: String = file.absolutePath
}

private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg", "ico")
private val audioExt = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "mid", "midi")
private val videoExt = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v")
private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "jar")
private val codeExt = setOf(
    "kt", "kts", "java", "js", "ts", "py", "c", "cpp", "h", "cs", "go", "rs", "php", "rb",
    "sh", "html", "htm", "css", "xml", "json", "yml", "yaml", "gradle", "sql", "lua", "dart", "swift"
)
private val textExt: Set<String> = codeExt + setOf(
    "txt", "log", "md", "ini", "conf", "cfg", "properties", "csv", "toml", "srt", "lrc", "bat", "gitignore"
)

/** Ekstensi arsip yang bisa dibuka/diekstrak oleh zenorX. */
val extractableExt = setOf("zip", "jar", "apk")

fun kindOf(file: File, isDir: Boolean): FileKind {
    if (isDir) return FileKind.FOLDER
    val e = file.extension.lowercase()
    return when {
        e == "apk" -> FileKind.APK
        e == "pdf" -> FileKind.PDF
        e in imageExt -> FileKind.IMAGE
        e in audioExt -> FileKind.AUDIO
        e in videoExt -> FileKind.VIDEO
        e in archiveExt -> FileKind.ARCHIVE
        e in codeExt -> FileKind.CODE
        e in textExt -> FileKind.TEXT
        else -> FileKind.OTHER
    }
}

fun isEditable(f: File): Boolean =
    f.extension.lowercase() in textExt && f.length() <= 2L * 1024 * 1024

/** Satu kali baca atribut (cepat) dengan cadangan File biasa. */
fun makeItem(f: File): FileItem {
    var d = false
    var size = 0L
    var mod = 0L
    try {
        val a = Files.readAttributes(f.toPath(), BasicFileAttributes::class.java)
        d = a.isDirectory
        size = if (d) 0L else a.size()
        mod = a.lastModifiedTime().toMillis()
    } catch (e: Exception) {
        d = f.isDirectory
        size = if (d) 0L else f.length()
        mod = f.lastModified()
    }
    return FileItem(f, d, size, mod, kindOf(f, d))
}

fun mimeOf(f: File): String {
    val ext = f.extension.lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}

fun humanSize(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.2f %s", v, units[i])
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

fun storageText(f: File): String = try {
    val s = StatFs(f.absolutePath)
    val total = s.totalBytes
    val used = total - s.availableBytes
    String.format(Locale.US, "%.2fG/%.2fG", used / 1073741824.0, total / 1073741824.0)
} catch (e: Exception) {
    "-"
}

private val shortFmt = SimpleDateFormat("dd/MM/yy", Locale.getDefault())
private val mtFmt = SimpleDateFormat("yy-MM-dd HH:mm", Locale.getDefault())
private val fullFmt = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())

fun formatShort(ms: Long): String = shortFmt.format(Date(ms))
fun formatMt(ms: Long): String = mtFmt.format(Date(ms))
fun formatFull(ms: Long): String = fullFmt.format(Date(ms))
