package com.zenorx.files

import android.util.Xml
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.File
import java.io.StringReader

enum class Lang { PLAIN, HTML, XML, CSS, JS, JSON, PYTHON, CLIKE, SHELL, YAML, MD, SQL, INI }

class LangSpec(
    val lang: Lang,
    val keywords: Set<String> = emptySet(),
    val lineComments: List<String> = emptyList(),
    val blockStart: String? = null,
    val blockEnd: String? = null,
    val quotes: String = "\"'",
    val ignoreCase: Boolean = false
)

/** Palet warna sintaks (gaya Darcula). */
object Syn {
    val plain = Color(0xFFA9B7C6)
    val keyword = Color(0xFFCC7832)
    val string = Color(0xFF6A8759)
    val number = Color(0xFF6897BB)
    val comment = Color(0xFF808080)
    val tag = Color(0xFFE8BF6A)
    val attr = Color(0xFF9876AA)
    val key = Color(0xFFD08A3C)
    val meta = Color(0xFFBBB529)
}

private val sKeyword = SpanStyle(color = Syn.keyword)
private val sString = SpanStyle(color = Syn.string)
private val sNumber = SpanStyle(color = Syn.number)
private val sComment = SpanStyle(color = Syn.comment, fontStyle = FontStyle.Italic)
private val sTag = SpanStyle(color = Syn.tag)
private val sAttr = SpanStyle(color = Syn.attr)
private val sKey = SpanStyle(color = Syn.key)
private val sMeta = SpanStyle(color = Syn.meta)

private val kotlinKw = setOf(
    "val", "var", "fun", "class", "object", "interface", "if", "else", "when", "for", "while", "do", "return",
    "break", "continue", "in", "is", "as", "try", "catch", "finally", "throw", "null", "true", "false", "this",
    "super", "import", "package", "override", "private", "public", "protected", "internal", "data", "sealed",
    "enum", "companion", "open", "abstract", "suspend", "by", "lateinit", "const", "typealias", "inline"
)
private val javaKw = setOf(
    "public", "private", "protected", "class", "interface", "extends", "implements", "new", "static", "final",
    "void", "int", "long", "double", "float", "boolean", "char", "byte", "short", "if", "else", "for", "while",
    "do", "switch", "case", "default", "break", "continue", "return", "try", "catch", "finally", "throw",
    "throws", "import", "package", "this", "super", "null", "true", "false", "instanceof", "abstract",
    "synchronized", "volatile", "enum"
)
private val cKw = javaKw + setOf(
    "struct", "typedef", "union", "sizeof", "namespace", "using", "template", "typename", "func", "fn", "let",
    "mut", "impl", "pub", "mod", "use", "defer", "go", "chan", "select", "range", "type", "var", "const",
    "function", "echo", "foreach", "as", "match", "async", "await", "string", "bool", "auto", "unsigned", "signed"
)
private val jsKw = setOf(
    "var", "let", "const", "function", "return", "if", "else", "for", "while", "do", "switch", "case", "default",
    "break", "continue", "new", "this", "class", "extends", "import", "export", "from", "async", "await", "try",
    "catch", "finally", "throw", "typeof", "instanceof", "in", "of", "null", "undefined", "true", "false",
    "delete", "void", "yield", "interface", "type", "enum", "implements", "public", "private", "static"
)
private val pyKw = setOf(
    "def", "class", "return", "if", "elif", "else", "for", "while", "in", "not", "and", "or", "is", "None",
    "True", "False", "import", "from", "as", "try", "except", "finally", "raise", "with", "lambda", "pass",
    "break", "continue", "global", "nonlocal", "yield", "async", "await", "del", "assert"
)
private val shKw = setOf(
    "if", "then", "else", "elif", "fi", "for", "while", "do", "done", "case", "esac", "function", "in",
    "echo", "exit", "return", "export", "local", "source", "cd", "set", "unset"
)
private val sqlKw = setOf(
    "select", "from", "where", "insert", "into", "values", "update", "set", "delete", "create", "table", "drop",
    "alter", "join", "left", "right", "inner", "outer", "on", "group", "by", "order", "having", "limit", "and",
    "or", "not", "null", "as", "distinct", "union", "primary", "key", "foreign", "references", "index", "like",
    "in", "is", "between", "case", "when", "then", "else", "end"
)

fun specFor(f: File): LangSpec {
    val slash = listOf("//")
    return when (f.extension.lowercase()) {
        "html", "htm", "xhtml", "svg" -> LangSpec(Lang.HTML)
        "xml", "xsd", "xsl", "plist" -> LangSpec(Lang.XML)
        "css", "scss", "less" -> LangSpec(Lang.CSS, blockStart = "/*", blockEnd = "*/")
        "js", "mjs", "cjs", "ts", "jsx", "tsx" ->
            LangSpec(Lang.JS, jsKw, slash, "/*", "*/", "\"'`")
        "json", "jsonc" -> LangSpec(Lang.JSON)
        "py", "pyw" -> LangSpec(Lang.PYTHON, pyKw, listOf("#"))
        "kt", "kts" -> LangSpec(Lang.CLIKE, kotlinKw, slash, "/*", "*/")
        "java" -> LangSpec(Lang.CLIKE, javaKw, slash, "/*", "*/")
        "rs" -> LangSpec(Lang.CLIKE, cKw, slash, "/*", "*/", "\"")
        "go" -> LangSpec(Lang.CLIKE, cKw, slash, "/*", "*/", "\"'`")
        "c", "h", "cpp", "hpp", "cc", "cs", "php", "dart", "swift", "gradle" ->
            LangSpec(Lang.CLIKE, cKw, slash, "/*", "*/")
        "sh", "bash", "zsh" -> LangSpec(Lang.SHELL, shKw, listOf("#"))
        "yml", "yaml" -> LangSpec(Lang.YAML)
        "md", "markdown" -> LangSpec(Lang.MD)
        "sql" -> LangSpec(Lang.SQL, sqlKw, listOf("--"), "/*", "*/", "\"'", true)
        "ini", "conf", "cfg", "properties", "toml", "env", "gitignore" -> LangSpec(Lang.INI)
        else -> LangSpec(Lang.PLAIN)
    }
}

fun supportsCheck(l: Lang): Boolean =
    l == Lang.HTML || l == Lang.XML || l == Lang.CSS || l == Lang.JS || l == Lang.JSON ||
        l == Lang.PYTHON || l == Lang.CLIKE || l == Lang.YAML || l == Lang.SQL

// ───────────────────────── highlight ─────────────────────────

fun highlight(text: String, spec: LangSpec): AnnotatedString {
    if (spec.lang == Lang.PLAIN || text.length > 250_000) return AnnotatedString(text)
    val b = AnnotatedString.Builder(text)
    when (spec.lang) {
        Lang.HTML -> hlMarkup(b, text, 0, text.length, true)
        Lang.XML -> hlMarkup(b, text, 0, text.length, false)
        Lang.CSS -> hlCss(b, text, 0, text.length)
        Lang.JSON -> hlJson(b, text)
        Lang.YAML -> hlYaml(b, text)
        Lang.INI -> hlIni(b, text)
        Lang.MD -> hlMd(b, text)
        else -> hlGeneric(b, text, 0, text.length, spec)
    }
    return b.toAnnotatedString()
}

private inline fun forEachLine(t: String, block: (Int, Int) -> Unit) {
    var s = 0
    while (s <= t.length) {
        var e = t.indexOf('\n', s)
        if (e < 0) e = t.length
        block(s, e)
        s = e + 1
    }
}

private fun hlGeneric(b: AnnotatedString.Builder, t: String, from: Int, to: Int, s: LangSpec) {
    val bs = s.blockStart
    val be = s.blockEnd
    val shell = s.lang == Lang.SHELL
    var i = from
    while (i < to) {
        val c = t[i]
        if (bs != null && be != null && t.startsWith(bs, i)) {
            val e = t.indexOf(be, i + bs.length)
            val end = if (e < 0 || e + be.length > to) to else e + be.length
            b.addStyle(sComment, i, end)
            i = end
            continue
        }
        var lc = false
        for (p in s.lineComments) {
            if (t.startsWith(p, i)) {
                lc = true
                break
            }
        }
        if (lc) {
            val e = t.indexOf('\n', i)
            val end = if (e < 0 || e > to) to else e
            b.addStyle(sComment, i, end)
            i = end
            continue
        }
        if (s.quotes.indexOf(c) >= 0) {
            val q3 = "$c$c$c"
            val triple = (s.lang == Lang.PYTHON || (s.lang == Lang.CLIKE && c == '"')) && t.startsWith(q3, i)
            var j: Int
            if (triple) {
                val e = t.indexOf(q3, i + 3)
                j = if (e < 0 || e + 3 > to) to else e + 3
            } else {
                j = i + 1
                val multi = c == '`'
                while (j < to) {
                    val d = t[j]
                    if (d == '\\') {
                        j += 2
                        continue
                    }
                    if (d == c) {
                        j++
                        break
                    }
                    if (d == '\n' && !multi) break
                    j++
                }
                if (j > to) j = to
            }
            b.addStyle(sString, i, j)
            i = j
            continue
        }
        if (c.isDigit() && (i == from || !(t[i - 1].isLetterOrDigit() || t[i - 1] == '_'))) {
            var j = i + 1
            while (j < to && (t[j].isLetterOrDigit() || t[j] == '.' || t[j] == '_')) j++
            b.addStyle(sNumber, i, j)
            i = j
            continue
        }
        if (c.isLetter() || c == '_') {
            var j = i + 1
            while (j < to && (t[j].isLetterOrDigit() || t[j] == '_')) j++
            val w = t.substring(i, j)
            val key = if (s.ignoreCase) w.lowercase() else w
            if (key in s.keywords) b.addStyle(sKeyword, i, j)
            i = j
            continue
        }
        if (c == '@' && i + 1 < to && t[i + 1].isLetter()) {
            var j = i + 1
            while (j < to && (t[j].isLetterOrDigit() || t[j] == '_' || t[j] == '.')) j++
            b.addStyle(sMeta, i, j)
            i = j
            continue
        }
        if (shell && c == '$' && i + 1 < to && (t[i + 1].isLetter() || t[i + 1] == '{' || t[i + 1] == '_')) {
            var j = i + 1
            if (t[j] == '{') {
                val e = t.indexOf('}', j)
                j = if (e < 0 || e >= to) to else e + 1
            } else {
                while (j < to && (t[j].isLetterOrDigit() || t[j] == '_')) j++
            }
            b.addStyle(sAttr, i, j)
            i = j
            continue
        }
        i++
    }
}

private fun indexOfIgnoreCase(t: String, needle: String, from: Int): Int =
    t.indexOf(needle, from, ignoreCase = true)

private val jsSpecInline = LangSpec(Lang.JS, jsKw, listOf("//"), "/*", "*/", "\"'`")

private fun hlMarkup(b: AnnotatedString.Builder, t: String, from: Int, to: Int, html: Boolean) {
    var i = from
    while (i < to) {
        val lt = t.indexOf('<', i)
        if (lt < 0 || lt >= to) break
        if (t.startsWith("<!--", lt)) {
            val e = t.indexOf("-->", lt + 4)
            val end = if (e < 0 || e + 3 > to) to else e + 3
            b.addStyle(sComment, lt, end)
            i = end
            continue
        }
        if (t.startsWith("<![CDATA[", lt)) {
            val e = t.indexOf("]]>", lt)
            val end = if (e < 0 || e + 3 > to) to else e + 3
            b.addStyle(sString, lt, end)
            i = end
            continue
        }
        if (t.startsWith("<?", lt) || t.startsWith("<!", lt)) {
            val e = t.indexOf('>', lt)
            val end = if (e < 0 || e + 1 > to) to else e + 1
            b.addStyle(sMeta, lt, end)
            i = end
            continue
        }
        var j = lt + 1
        val closing = j < to && t[j] == '/'
        if (closing) j++
        val nameStart = j
        while (j < to && (t[j].isLetterOrDigit() || t[j] == ':' || t[j] == '-' || t[j] == '_' || t[j] == '.')) j++
        if (j == nameStart) {
            i = lt + 1
            continue
        }
        val name = t.substring(nameStart, j)
        b.addStyle(sTag, lt, j)
        while (j < to && t[j] != '>') {
            val ch = t[j]
            if (ch == '"' || ch == '\'') {
                val e = t.indexOf(ch, j + 1)
                val end = if (e < 0 || e >= to) to else e + 1
                b.addStyle(sString, j, end)
                j = end
            } else if (ch.isLetter() || ch == '_' || ch == ':' || ch == '@') {
                val s0 = j
                while (j < to && (t[j].isLetterOrDigit() || t[j] == ':' || t[j] == '-' || t[j] == '_' || t[j] == '.' || t[j] == '@')) j++
                b.addStyle(sAttr, s0, j)
            } else {
                if (ch == '/') b.addStyle(sTag, j, j + 1)
                j++
            }
        }
        if (j < to) {
            b.addStyle(sTag, j, j + 1)
            j++
        }
        i = j
        if (html && !closing && (name.equals("script", true) || name.equals("style", true))) {
            val close = indexOfIgnoreCase(t, "</$name", i)
            val end = if (close < 0 || close > to) to else close
            if (name.equals("script", true)) hlGeneric(b, t, i, end, jsSpecInline) else hlCss(b, t, i, end)
            i = end
        }
    }
}

private fun hlCss(b: AnnotatedString.Builder, t: String, from: Int, to: Int) {
    var i = from
    var depth = 0
    var inValue = false
    while (i < to) {
        val c = t[i]
        if (t.startsWith("/*", i)) {
            val e = t.indexOf("*/", i + 2)
            val end = if (e < 0 || e + 2 > to) to else e + 2
            b.addStyle(sComment, i, end)
            i = end
            continue
        }
        if (c == '"' || c == '\'') {
            var j = i + 1
            while (j < to && t[j] != c && t[j] != '\n') {
                if (t[j] == '\\') j++
                j++
            }
            if (j < to && t[j] == c) j++
            if (j > to) j = to
            b.addStyle(sString, i, j)
            i = j
            continue
        }
        if (c == '{') {
            depth++
            inValue = false
            i++
            continue
        }
        if (c == '}') {
            if (depth > 0) depth--
            inValue = false
            i++
            continue
        }
        if (c == ';') {
            inValue = false
            i++
            continue
        }
        if (c.isWhitespace()) {
            i++
            continue
        }
        if (depth == 0) {
            var j = i
            while (j < to && t[j] != '{' && t[j] != '}' && t[j] != ';' && !t.startsWith("/*", j)) j++
            var e = j
            while (e > i && t[e - 1].isWhitespace()) e--
            if (e > i) b.addStyle(if (c == '@') sKeyword else sTag, i, e)
            i = if (j == i) i + 1 else j
            continue
        }
        if (!inValue && (c.isLetter() || c == '-' || c == '_')) {
            var j = i
            while (j < to && (t[j].isLetterOrDigit() || t[j] == '-' || t[j] == '_')) j++
            var k = j
            while (k < to && t[k] == ' ') k++
            if (k < to && t[k] == ':') {
                b.addStyle(sAttr, i, j)
                inValue = true
                i = k + 1
            } else {
                b.addStyle(sTag, i, j)
                i = j
            }
            continue
        }
        if (inValue) {
            if (c == '#') {
                var j = i + 1
                while (j < to && t[j].isLetterOrDigit()) j++
                b.addStyle(sNumber, i, j)
                i = j
                continue
            }
            if (c.isDigit() || (c == '.' && i + 1 < to && t[i + 1].isDigit())) {
                var j = i + 1
                while (j < to && (t[j].isLetterOrDigit() || t[j] == '.' || t[j] == '%')) j++
                b.addStyle(sNumber, i, j)
                i = j
                continue
            }
            if (c == '!') {
                var j = i + 1
                while (j < to && t[j].isLetter()) j++
                b.addStyle(sKeyword, i, j)
                i = j
                continue
            }
        }
        i++
    }
}

private fun hlJson(b: AnnotatedString.Builder, t: String) {
    val n = t.length
    var i = 0
    while (i < n) {
        val c = t[i]
        if (c == '"') {
            var j = i + 1
            while (j < n && t[j] != '"' && t[j] != '\n') {
                if (t[j] == '\\') j++
                j++
            }
            if (j < n && t[j] == '"') j++
            if (j > n) j = n
            var k = j
            while (k < n && (t[k] == ' ' || t[k] == '\t' || t[k] == '\n' || t[k] == '\r')) k++
            b.addStyle(if (k < n && t[k] == ':') sKey else sString, i, j)
            i = j
            continue
        }
        if (c == '-' || c.isDigit()) {
            var j = i + 1
            while (j < n && (t[j].isDigit() || t[j] == '.' || t[j] == 'e' || t[j] == 'E' || t[j] == '+' || t[j] == '-')) j++
            b.addStyle(sNumber, i, j)
            i = j
            continue
        }
        if (c.isLetter()) {
            var j = i + 1
            while (j < n && t[j].isLetter()) j++
            val w = t.substring(i, j)
            if (w == "true" || w == "false" || w == "null") b.addStyle(sKeyword, i, j)
            i = j
            continue
        }
        i++
    }
}

private fun hlYamlValue(b: AnnotatedString.Builder, t: String, from: Int, to: Int): Boolean {
    var i = from
    var block = false
    while (i < to) {
        val c = t[i]
        if (c == ' ') {
            i++
            continue
        }
        if (c == '#' && (i == from || t[i - 1] == ' ')) {
            b.addStyle(sComment, i, to)
            break
        }
        if (c == '"' || c == '\'') {
            var j = i + 1
            while (j < to && t[j] != c) {
                if (c == '"' && t[j] == '\\') j++
                j++
            }
            if (j < to) j++
            if (j > to) j = to
            b.addStyle(sString, i, j)
            block = false
            i = j
            continue
        }
        var j = i
        while (j < to && t[j] != ' ') j++
        val w = t.substring(i, j)
        block = false
        if (c == '&' || c == '*' || c == '!' || w.startsWith("\${{")) {
            b.addStyle(sMeta, i, j)
        } else if (w == "|" || w == ">" || w == "|-" || w == ">-" || w == "|+" || w == ">+") {
            b.addStyle(sKeyword, i, j)
            block = true
        } else if (w == "true" || w == "false" || w == "null" || w == "yes" || w == "no" || w == "~") {
            b.addStyle(sKeyword, i, j)
        } else if (w.isNotEmpty() && (w[0].isDigit() || (w[0] == '-' && w.length > 1 && w[1].isDigit())) && w.all { it.isDigit() || it == '.' || it == '-' }) {
            b.addStyle(sNumber, i, j)
        }
        i = j
    }
    return block
}

private fun hlYaml(b: AnnotatedString.Builder, t: String) {
    var blockIndent = -1
    forEachLine(t) { ls, le ->
        var i = ls
        while (i < le && t[i] == ' ') i++
        val indent = i - ls
        if (blockIndent >= 0) {
            if (i >= le || indent > blockIndent) return@forEachLine
            blockIndent = -1
        }
        if (i >= le) return@forEachLine
        if (t[i] == '#') {
            b.addStyle(sComment, i, le)
            return@forEachLine
        }
        var p = i
        if (t[p] == '-' && (p + 1 >= le || t[p + 1] == ' ')) {
            b.addStyle(sKeyword, p, p + 1)
            p++
            while (p < le && t[p] == ' ') p++
        }
        var q = p
        var quote = ' '
        var colon = -1
        while (q < le) {
            val ch = t[q]
            if (quote != ' ') {
                if (ch == quote) quote = ' '
            } else if (ch == '"' || ch == '\'') {
                quote = ch
            } else if (ch == '#' && (q == p || t[q - 1] == ' ')) {
                break
            } else if (ch == ':' && (q + 1 >= le || t[q + 1] == ' ')) {
                colon = q
                break
            }
            q++
        }
        var vs = p
        if (colon > p) {
            b.addStyle(sKey, p, colon)
            vs = colon + 1
        }
        if (hlYamlValue(b, t, vs, le)) blockIndent = indent
    }
}

private fun hlIni(b: AnnotatedString.Builder, t: String) {
    forEachLine(t) { ls, le ->
        var i = ls
        while (i < le && (t[i] == ' ' || t[i] == '\t')) i++
        if (i >= le) return@forEachLine
        val c = t[i]
        if (c == '#' || c == ';' || c == '!') {
            b.addStyle(sComment, i, le)
            return@forEachLine
        }
        if (c == '[') {
            val e = t.indexOf(']', i)
            if (e in i until le) b.addStyle(sTag, i, e + 1)
            return@forEachLine
        }
        var eq = -1
        var j = i
        while (j < le) {
            if (t[j] == '=' || t[j] == ':') {
                eq = j
                break
            }
            j++
        }
        if (eq > i) {
            b.addStyle(sKey, i, eq)
            var v = eq + 1
            while (v < le && t[v] == ' ') v++
            if (v < le) {
                val d = t[v]
                if (d == '"' || d == '\'') b.addStyle(sString, v, le)
                else if (d.isDigit()) b.addStyle(sNumber, v, le)
            }
        }
    }
}

private fun hlMd(b: AnnotatedString.Builder, t: String) {
    var fence = false
    forEachLine(t) { ls, le ->
        if (t.startsWith("```", ls)) {
            fence = !fence
            b.addStyle(sComment, ls, le)
            return@forEachLine
        }
        if (fence) {
            b.addStyle(sString, ls, le)
            return@forEachLine
        }
        if (ls < le && t[ls] == '#') {
            b.addStyle(SpanStyle(color = Syn.keyword, fontWeight = FontWeight.Bold), ls, le)
            return@forEachLine
        }
        if (ls < le && t[ls] == '>') {
            b.addStyle(sComment, ls, le)
            return@forEachLine
        }
        var k = ls
        while (k < le) {
            val c = t[k]
            if (c == '`') {
                val e = t.indexOf('`', k + 1)
                if (e in (k + 1) until le) {
                    b.addStyle(sString, k, e + 1)
                    k = e + 1
                    continue
                }
            }
            if (c == '*' && k + 1 < le && t[k + 1] == '*') {
                val e = t.indexOf("**", k + 2)
                if (e in (k + 2) until le) {
                    b.addStyle(SpanStyle(color = Syn.tag, fontWeight = FontWeight.Bold), k, e + 2)
                    k = e + 2
                    continue
                }
            }
            if (c == '[') {
                val e = t.indexOf("](", k)
                val e2 = if (e > 0) t.indexOf(')', e) else -1
                if (e in (k + 1) until le && e2 in e until le) {
                    b.addStyle(sAttr, k, e2 + 1)
                    k = e2 + 1
                    continue
                }
            }
            k++
        }
    }
}

// ───────────────────────── pemeriksa sintaks ─────────────────────────

/** resId = string resource, arg = argumen %1$s (boleh kosong). */
class CheckError(val resId: Int, val arg: String)

class CheckResult(val errors: Map<Int, CheckError>, val supported: Boolean)

private fun MutableMap<Int, CheckError>.addErr(line: Int, res: Int, arg: String) {
    if (size < 60 && !containsKey(line)) put(line, CheckError(res, arg))
}

private fun countNl(t: String, from: Int, to: Int): Int {
    var c = 0
    var i = from
    val e = minOf(to, t.length)
    while (i < e) {
        if (t[i] == '\n') c++
        i++
    }
    return c
}

fun checkCode(t: String, spec: LangSpec): CheckResult {
    val errs = LinkedHashMap<Int, CheckError>()
    when (spec.lang) {
        Lang.JSON -> checkJson(t, errs)
        Lang.XML -> checkXml(t, errs)
        Lang.HTML -> checkHtml(t, errs)
        Lang.YAML -> checkYaml(t, errs)
        Lang.PYTHON -> {
            scanBalance(t, spec, errs)
            checkPython(t, errs)
        }
        Lang.JS, Lang.CSS, Lang.CLIKE, Lang.SQL -> scanBalance(t, spec, errs)
        else -> return CheckResult(errs, false)
    }
    return CheckResult(errs, true)
}

private fun scanBalance(t: String, s: LangSpec, errs: MutableMap<Int, CheckError>) {
    val openCh = ArrayList<Char>()
    val openLine = ArrayList<Int>()
    val bs = s.blockStart
    val be = s.blockEnd
    val py = s.lang == Lang.PYTHON
    val js = s.lang == Lang.JS
    val n = t.length
    var line = 0
    var i = 0
    var prev = ' '
    while (i < n) {
        val c = t[i]
        if (c == '\n') {
            line++
            i++
            continue
        }
        if (c == ' ' || c == '\t' || c == '\r') {
            i++
            continue
        }
        if (bs != null && be != null && t.startsWith(bs, i)) {
            val e = t.indexOf(be, i + bs.length)
            if (e < 0) {
                errs.addErr(line, R.string.chk_unterminated_comment, "")
                break
            }
            line += countNl(t, i, e)
            i = e + be.length
            continue
        }
        var lc = false
        for (p in s.lineComments) {
            if (t.startsWith(p, i)) {
                lc = true
                break
            }
        }
        if (lc) {
            val e = t.indexOf('\n', i)
            i = if (e < 0) n else e
            continue
        }
        if (js && c == '/' && (prev == ' ' || "(,=:[!&|?{};".indexOf(prev) >= 0)) {
            var j = i + 1
            var cls = false
            var ok = false
            while (j < n && t[j] != '\n') {
                val d = t[j]
                if (d == '\\') {
                    j += 2
                    continue
                }
                if (d == '[') cls = true
                else if (d == ']') cls = false
                else if (d == '/' && !cls) {
                    ok = true
                    break
                }
                j++
            }
            if (ok) {
                i = j + 1
                prev = '/'
                continue
            }
        }
        if (s.quotes.indexOf(c) >= 0) {
            val q3 = "$c$c$c"
            if ((py || (s.lang == Lang.CLIKE && c == '"')) && t.startsWith(q3, i)) {
                val e = t.indexOf(q3, i + 3)
                if (e < 0) {
                    errs.addErr(line, R.string.chk_unterminated_string, "")
                    break
                }
                line += countNl(t, i, e)
                i = e + 3
                prev = c
                continue
            }
            val multi = c == '`'
            var j = i + 1
            var closed = false
            val startLine = line
            while (j < n) {
                val d = t[j]
                if (d == '\\') {
                    if (j + 1 < n && t[j + 1] == '\n') line++
                    j += 2
                    continue
                }
                if (d == c) {
                    closed = true
                    break
                }
                if (d == '\n') {
                    if (multi) line++ else break
                }
                j++
            }
            if (!closed) {
                errs.addErr(startLine, R.string.chk_unterminated_string, "")
                i = j
                continue
            }
            i = j + 1
            prev = c
            continue
        }
        if (c == '(' || c == '[' || c == '{') {
            openCh.add(c)
            openLine.add(line)
            prev = c
            i++
            continue
        }
        if (c == ')' || c == ']' || c == '}') {
            if (openCh.isEmpty()) {
                errs.addErr(line, R.string.chk_unmatched, c.toString())
            } else {
                val o = openCh.removeAt(openCh.size - 1)
                val ol = openLine.removeAt(openLine.size - 1)
                val want = when (o) {
                    '(' -> ')'
                    '[' -> ']'
                    else -> '}'
                }
                if (want != c) {
                    errs.addErr(line, R.string.chk_mismatch, o.toString())
                    errs.addErr(ol, R.string.chk_unclosed, o.toString())
                }
            }
            prev = c
            i++
            continue
        }
        prev = c
        i++
    }
    for (k in openCh.indices) errs.addErr(openLine[k], R.string.chk_unclosed, openCh[k].toString())
}

private class JsonErr(val pos: Int, val res: Int) : Exception()

private class JsonParser(private val t: String) {
    private var i = 0

    private fun fail(res: Int): Nothing = throw JsonErr(i, res)

    private fun ws() {
        while (i < t.length && (t[i] == ' ' || t[i] == '\t' || t[i] == '\n' || t[i] == '\r')) i++
    }

    fun parseAll() {
        ws()
        if (i >= t.length) fail(R.string.chk_json_end)
        value(0)
        ws()
        if (i < t.length) fail(R.string.chk_json_trailing)
    }

    private fun value(depth: Int) {
        if (depth > 300) fail(R.string.chk_json_value)
        ws()
        if (i >= t.length) fail(R.string.chk_json_end)
        val c = t[i]
        if (c == '{') obj(depth)
        else if (c == '[') arr(depth)
        else if (c == '"') str()
        else if (c == '-' || c.isDigit()) num()
        else if (t.startsWith("true", i)) i += 4
        else if (t.startsWith("false", i)) i += 5
        else if (t.startsWith("null", i)) i += 4
        else fail(R.string.chk_json_value)
    }

    private fun obj(depth: Int) {
        i++
        ws()
        if (i < t.length && t[i] == '}') {
            i++
            return
        }
        while (true) {
            ws()
            if (i >= t.length) fail(R.string.chk_json_end)
            if (t[i] != '"') fail(R.string.chk_json_key)
            str()
            ws()
            if (i >= t.length || t[i] != ':') fail(R.string.chk_json_colon)
            i++
            value(depth + 1)
            ws()
            if (i >= t.length) fail(R.string.chk_json_end)
            if (t[i] == ',') {
                i++
                continue
            }
            if (t[i] == '}') {
                i++
                return
            }
            fail(R.string.chk_json_comma)
        }
    }

    private fun arr(depth: Int) {
        i++
        ws()
        if (i < t.length && t[i] == ']') {
            i++
            return
        }
        while (true) {
            value(depth + 1)
            ws()
            if (i >= t.length) fail(R.string.chk_json_end)
            if (t[i] == ',') {
                i++
                continue
            }
            if (t[i] == ']') {
                i++
                return
            }
            fail(R.string.chk_json_comma)
        }
    }

    private fun str() {
        i++
        while (i < t.length) {
            val c = t[i]
            if (c == '"') {
                i++
                return
            }
            if (c == '\n') fail(R.string.chk_json_string)
            if (c == '\\') {
                i += 2
                continue
            }
            i++
        }
        fail(R.string.chk_json_string)
    }

    private fun num() {
        if (t[i] == '-') i++
        if (i >= t.length || !t[i].isDigit()) fail(R.string.chk_json_number)
        while (i < t.length && t[i].isDigit()) i++
        if (i < t.length && t[i] == '.') {
            i++
            if (i >= t.length || !t[i].isDigit()) fail(R.string.chk_json_number)
            while (i < t.length && t[i].isDigit()) i++
        }
        if (i < t.length && (t[i] == 'e' || t[i] == 'E')) {
            i++
            if (i < t.length && (t[i] == '+' || t[i] == '-')) i++
            if (i >= t.length || !t[i].isDigit()) fail(R.string.chk_json_number)
            while (i < t.length && t[i].isDigit()) i++
        }
    }
}

private fun checkJson(t: String, errs: MutableMap<Int, CheckError>) {
    try {
        JsonParser(t).parseAll()
    } catch (e: JsonErr) {
        errs.addErr(countNl(t, 0, e.pos), e.res, "")
    }
}

private fun checkXml(t: String, errs: MutableMap<Int, CheckError>) {
    try {
        val p = Xml.newPullParser()
        p.setInput(StringReader(t))
        while (p.next() != XmlPullParser.END_DOCUMENT) {
        }
    } catch (e: XmlPullParserException) {
        val ln = (e.lineNumber - 1).coerceAtLeast(0)
        errs.addErr(ln, R.string.chk_xml, (e.message ?: "").substringBefore(" (position").take(120))
    } catch (e: Exception) {
        errs.addErr(0, R.string.chk_xml, e.message ?: "")
    }
}

private val voidTags = setOf(
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"
)
private val optionalClose = setOf(
    "p", "li", "dt", "dd", "tr", "td", "th", "thead", "tbody", "tfoot", "option", "optgroup",
    "colgroup", "body", "html", "head"
)

private fun checkHtml(t: String, errs: MutableMap<Int, CheckError>) {
    val names = ArrayList<String>()
    val lines = ArrayList<Int>()
    val n = t.length
    var i = 0
    var line = 0
    while (i < n) {
        val c = t[i]
        if (c == '\n') {
            line++
            i++
            continue
        }
        if (c != '<') {
            i++
            continue
        }
        if (t.startsWith("<!--", i)) {
            val e = t.indexOf("-->", i + 4)
            if (e < 0) {
                errs.addErr(line, R.string.chk_unterminated_comment, "")
                break
            }
            line += countNl(t, i, e)
            i = e + 3
            continue
        }
        if (i + 1 < n && (t[i + 1] == '!' || t[i + 1] == '?')) {
            val e = t.indexOf('>', i)
            if (e < 0) break
            line += countNl(t, i, e)
            i = e + 1
            continue
        }
        var j = i + 1
        val closing = j < n && t[j] == '/'
        if (closing) j++
        val ns = j
        while (j < n && (t[j].isLetterOrDigit() || t[j] == '-' || t[j] == ':' || t[j] == '_')) j++
        if (j == ns) {
            i++
            continue
        }
        val name = t.substring(ns, j).lowercase()
        val tagLine = line
        var selfClose = false
        var ok = false
        while (j < n) {
            val d = t[j]
            if (d == '"' || d == '\'') {
                val e = t.indexOf(d, j + 1)
                if (e < 0) {
                    errs.addErr(line, R.string.chk_html_attr, "")
                    j = n
                    break
                }
                line += countNl(t, j, e)
                j = e + 1
                continue
            }
            if (d == '\n') line++
            if (d == '>') {
                ok = true
                selfClose = j > 0 && t[j - 1] == '/'
                j++
                break
            }
            j++
        }
        i = j
        if (!ok) break
        if (closing) {
            while (names.isNotEmpty() && names[names.size - 1] != name && names[names.size - 1] in optionalClose) {
                names.removeAt(names.size - 1)
                lines.removeAt(lines.size - 1)
            }
            if (names.isNotEmpty() && names[names.size - 1] == name) {
                names.removeAt(names.size - 1)
                lines.removeAt(lines.size - 1)
            } else {
                errs.addErr(tagLine, R.string.chk_html_unexpected_close, name)
            }
        } else if (!selfClose && name !in voidTags) {
            names.add(name)
            lines.add(tagLine)
            if (name == "script" || name == "style" || name == "textarea") {
                val e = t.indexOf("</$name", i, ignoreCase = true)
                if (e >= 0) {
                    line += countNl(t, i, e)
                    i = e
                }
            }
        }
    }
    for (k in names.indices) {
        if (names[k] !in optionalClose) errs.addErr(lines[k], R.string.chk_html_unclosed, names[k])
    }
}

private fun checkYaml(t: String, errs: MutableMap<Int, CheckError>) {
    val stack = ArrayList<Int>()
    stack.add(0)
    var blockIndent = -1
    var line = -1
    forEachLine(t) { ls, le0 ->
        line++
        val le = if (le0 > ls && t[le0 - 1] == '\r') le0 - 1 else le0
        var i = ls
        var sawTab = false
        while (i < le && (t[i] == ' ' || t[i] == '\t')) {
            if (t[i] == '\t') sawTab = true
            i++
        }
        if (i >= le) return@forEachLine
        val indent = i - ls
        if (blockIndent >= 0) {
            if (indent > blockIndent) return@forEachLine
            blockIndent = -1
        }
        if (t[i] == '#') return@forEachLine
        if (sawTab) {
            errs.addErr(line, R.string.chk_yaml_tab, "")
            return@forEachLine
        }
        val top = stack[stack.size - 1]
        if (indent > top) {
            stack.add(indent)
        } else if (indent < top) {
            while (stack.size > 1 && stack[stack.size - 1] > indent) stack.removeAt(stack.size - 1)
            if (stack[stack.size - 1] != indent) errs.addErr(line, R.string.chk_yaml_indent, "")
        }
        var vs = i
        if (t[vs] == '-' && (vs + 1 >= le || t[vs + 1] == ' ')) {
            vs++
            while (vs < le && t[vs] == ' ') vs++
        }
        var ci = -1
        var k = vs
        while (k + 1 < le) {
            if (t[k] == ':' && t[k + 1] == ' ') {
                ci = k
                break
            }
            k++
        }
        var valStart = vs
        if (ci >= 0) {
            valStart = ci + 2
            while (valStart < le && t[valStart] == ' ') valStart++
        } else if (le > vs && t[le - 1] == ':') {
            valStart = le
        }
        if (valStart < le && t[valStart] == '"') {
            var q = valStart + 1
            var closed = false
            while (q < le) {
                if (t[q] == '\\') {
                    q += 2
                    continue
                }
                if (t[q] == '"') {
                    closed = true
                    break
                }
                q++
            }
            if (!closed) errs.addErr(line, R.string.chk_yaml_quote, "")
        }
        val rest = if (valStart < le) t.substring(valStart, le).substringBefore(" #").trim() else ""
        if (rest == "|" || rest == "|-" || rest == "|+" || rest == ">" || rest == ">-" || rest == ">+") {
            blockIndent = indent
        }
    }
}

private val pyBlockKw = setOf("if", "elif", "else", "for", "while", "def", "class", "try", "except", "finally", "with")

private fun checkPython(t: String, errs: MutableMap<Int, CheckError>) {
    val n = t.length
    var i = 0
    var line = 0
    val stack = ArrayList<Int>()
    stack.add(0)
    var prevOpens = false
    var first = true
    while (i < n) {
        var j = i
        var spaces = 0
        var tabs = 0
        while (j < n && (t[j] == ' ' || t[j] == '\t')) {
            if (t[j] == ' ') spaces++ else tabs++
            j++
        }
        if (j >= n) break
        if (t[j] == '\n' || t[j] == '\r') {
            if (t[j] == '\n') line++
            i = j + 1
            continue
        }
        if (t[j] == '#') {
            val e = t.indexOf('\n', j)
            if (e < 0) break
            line++
            i = e + 1
            continue
        }
        val startLine = line
        val indent = spaces + tabs * 8
        val mixed = spaces > 0 && tabs > 0
        val code = StringBuilder()
        var d = 0
        var colon0 = false
        var k = j
        while (k < n) {
            val c = t[k]
            if (c == '\\' && k + 1 < n && t[k + 1] == '\n') {
                line++
                k += 2
                continue
            }
            if (c == '\n') {
                line++
                k++
                if (d > 0) {
                    code.append(' ')
                    continue
                }
                break
            }
            if (c == '#') {
                val e = t.indexOf('\n', k)
                k = if (e < 0) n else e
                continue
            }
            if (c == '"' || c == '\'') {
                val q3 = "$c$c$c"
                if (t.startsWith(q3, k)) {
                    val e = t.indexOf(q3, k + 3)
                    if (e < 0) {
                        k = n
                    } else {
                        line += countNl(t, k, e)
                        k = e + 3
                    }
                } else {
                    var m = k + 1
                    while (m < n && t[m] != c && t[m] != '\n') {
                        if (t[m] == '\\') m++
                        m++
                    }
                    k = if (m < n && t[m] == c) m + 1 else m
                }
                code.append('S')
                continue
            }
            if (c == '(' || c == '[' || c == '{') d++
            else if (c == ')' || c == ']' || c == '}') {
                if (d > 0) d--
            } else if (c == ':' && d == 0) colon0 = true
            code.append(c)
            k++
        }
        i = k
        val text = code.toString().trim()
        val firstWord = text.takeWhile { it.isLetter() || it == '_' }
        val kw = if (firstWord == "async") text.removePrefix("async").trim().takeWhile { it.isLetter() || it == '_' } else firstWord
        val blockKw = kw in pyBlockKw
        if (blockKw && !colon0) errs.addErr(startLine, R.string.chk_py_colon, kw)
        val opens = text.endsWith(":")
        if (mixed) errs.addErr(startLine, R.string.chk_py_tabs, "")
        val top = stack[stack.size - 1]
        if (first) {
            if (indent > 0) {
                errs.addErr(startLine, R.string.chk_py_indent, "")
                stack.add(indent)
            }
        } else if (indent > top) {
            if (!prevOpens) errs.addErr(startLine, R.string.chk_py_indent, "")
            stack.add(indent)
        } else if (indent < top) {
            while (stack.size > 1 && stack[stack.size - 1] > indent) stack.removeAt(stack.size - 1)
            if (stack[stack.size - 1] != indent) errs.addErr(startLine, R.string.chk_py_unindent, "")
        } else if (prevOpens) {
            errs.addErr(startLine, R.string.chk_py_expected_block, "")
        }
        prevOpens = opens
        first = false
    }
}
