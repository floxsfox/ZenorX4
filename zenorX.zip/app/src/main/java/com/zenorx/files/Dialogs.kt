package com.zenorx.files

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun DialogHost(vm: FilesViewModel) {
    val ctx = LocalContext.current
    when (val d = vm.dlg) {
        is Dlg.Rename -> NameDialog(
            stringResource(R.string.rename), d.file.name, stringResource(R.string.save), !d.file.isDirectory,
            onDismiss = { vm.dlg = null }
        ) { vm.dlg = null; vm.rename(d.file, it) }

        is Dlg.NewFolder -> NameDialog(
            stringResource(R.string.new_folder), "", stringResource(R.string.create), false,
            onDismiss = { vm.dlg = null }
        ) { vm.dlg = null; vm.createFolder(d.dir, it) }

        is Dlg.NewFile -> NameDialog(
            stringResource(R.string.new_file), "", stringResource(R.string.create), false,
            onDismiss = { vm.dlg = null }
        ) { vm.dlg = null; vm.createFile(d.dir, it) }

        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { vm.dlg = null },
            title = { Text(stringResource(R.string.delete)) },
            text = {
                Text(
                    if (d.files.size == 1) stringResource(R.string.delete_one, d.files[0].name)
                    else stringResource(R.string.delete_many, d.files.size)
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.dlg = null; vm.delete(d.files) }) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.cancel)) } }
        )

        is Dlg.CreateArchive -> CreateArchiveDialog(vm, d)
        is Dlg.Password -> PasswordDialog(vm, d)

        is Dlg.SelfUpdate -> AlertDialog(
            onDismissRequest = { vm.dlg = null },
            title = { Text(stringResource(R.string.self_update_title)) },
            text = { Text(stringResource(R.string.self_update_text)) },
            confirmButton = {
                TextButton(onClick = { vm.dlg = null; vm.proceedInstall(ctx, d.file) }) {
                    Text(stringResource(R.string.continue_word))
                }
            },
            dismissButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.cancel)) } }
        )

        is Dlg.InstallPerm -> AlertDialog(
            onDismissRequest = { vm.dlg = null },
            title = { Text(stringResource(R.string.install_perm_title)) },
            text = { Text(stringResource(R.string.install_perm_text)) },
            confirmButton = {
                TextButton(onClick = { vm.dlg = null; vm.openInstallSettings(ctx, d.file) }) {
                    Text(stringResource(R.string.open_settings))
                }
            },
            dismissButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.cancel)) } }
        )

        Dlg.Prefs -> PrefsDialog(vm)
        Dlg.ViewOpts -> AlertDialog(
            onDismissRequest = { vm.dlg = null },
            confirmButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.close)) } },
            text = { ViewOptionsContent(vm) }
        )
        Dlg.About -> AboutDialog { vm.dlg = null }
        null -> {}
    }
    vm.sheet?.let { FileSheet(vm, it) }
    vm.props?.let { PropsDialog(vm, it) }
    vm.dropReq?.let { DropDialog(vm, it) }
    vm.busy?.let { BusyDialog(vm, it) }
    vm.archive?.let { ArchiveDialog(vm, it) }
    vm.editing?.let { CodeEditorDialog(vm, it) }
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    selectBase: Boolean,
    onDismiss: () -> Unit,
    onOk: (String) -> Unit
) {
    val dot = initial.lastIndexOf('.')
    val end = if (selectBase && dot > 0) dot else initial.length
    var tf by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, end))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = tf,
                onValueChange = { tf = it },
                singleLine = true,
                modifier = Modifier.focusRequester(focus),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (tf.text.isNotBlank()) onOk(tf.text) })
            )
        },
        confirmButton = {
            TextButton(onClick = { onOk(tf.text) }, enabled = tf.text.isNotBlank()) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

// ───────────────────────── Buat Arsip (gaya ZArchiver) ─────────────────────────

@Composable
private fun DropField(
    label: String,
    options: List<String>,
    selected: Int,
    enabled: Boolean,
    modifier: Modifier,
    onSelect: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = cs.onSurfaceVariant)
        Box {
            Row(
                Modifier.fillMaxWidth().clickable(enabled = enabled) { open = true }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    options[selected.coerceIn(0, options.size - 1)], fontSize = 15.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    color = if (enabled) cs.onSurface else cs.onSurfaceVariant
                )
                Icon(Icons.Filled.ArrowDropDown, null, tint = cs.onSurfaceVariant)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEachIndexed { i, o ->
                    DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onSelect(i) })
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(cs.outline))
    }
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(label, fontSize = 14.sp)
    }
}

@Composable
fun CreateArchiveDialog(vm: FilesViewModel, req: Dlg.CreateArchive) {
    val cs = MaterialTheme.colorScheme
    val first = req.files[0]
    val defaultName = remember(req) {
        val base = if (req.files.size == 1) {
            if (first.isDirectory) first.name else first.nameWithoutExtension
        } else {
            req.dir.name.ifEmpty { "archive" }
        }
        "$base.zip"
    }
    var name by remember(req) { mutableStateOf(defaultName) }
    var dest by remember(req) { mutableStateOf(req.dir) }
    var level by remember { mutableStateOf(3) }
    var enc by remember { mutableStateOf(0) }
    var password by remember { mutableStateOf("") }
    var showPw by remember { mutableStateOf(false) }
    var volIdx by remember { mutableStateOf(0) }
    var deleteSrc by remember { mutableStateOf(false) }
    var separate by remember { mutableStateOf(false) }
    var destMenu by remember { mutableStateOf(false) }

    val levels = listOf(
        stringResource(R.string.level_store), stringResource(R.string.level_fastest),
        stringResource(R.string.level_fast), stringResource(R.string.level_normal),
        stringResource(R.string.level_max)
    )
    val encs = listOf(
        stringResource(R.string.enc_zipcrypto), stringResource(R.string.enc_aes128),
        stringResource(R.string.enc_aes256)
    )
    val volLabels = listOf(
        stringResource(R.string.vol_none), "10 MB", "50 MB", "100 MB", "500 MB", "1 GB"
    )
    val volBytes = longArrayOf(0L, 10L shl 20, 50L shl 20, 100L shl 20, 500L shl 20, 1L shl 30)
    val places = remember { placesOf(vm) }
    val other = vm.panel(1 - vm.active).path

    AlertDialog(
        onDismissRequest = { vm.dlg = null },
        title = { Text(stringResource(R.string.create_archive_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.archive_label), fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Box {
                        Button(
                            onClick = { destMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = cs.surfaceVariant, contentColor = cs.onSurface)
                        ) { Text("…") }
                        DropdownMenu(expanded = destMenu, onDismissRequest = { destMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.dest_current)) },
                                onClick = { destMenu = false; dest = req.dir }
                            )
                            if (vm.dual) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.dest_other_panel)) },
                                    onClick = { destMenu = false; dest = other }
                                )
                            }
                            places.forEach { pl ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(pl.labelRes)) },
                                    onClick = { destMenu = false; dest = pl.dir }
                                )
                            }
                        }
                    }
                }
                Text(
                    stringResource(R.string.save_to, dest.absolutePath), fontSize = 11.sp,
                    color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Row {
                    DropField(stringResource(R.string.format_label), listOf("zip"), 0, true, Modifier.weight(1f)) { }
                    Spacer(Modifier.width(16.dp))
                    DropField(stringResource(R.string.level_label), levels, level, true, Modifier.weight(1f)) { level = it }
                }
                Spacer(Modifier.height(8.dp))
                DropField(
                    stringResource(R.string.encryption_label), encs, enc, password.isNotEmpty(), Modifier.fillMaxWidth()
                ) { enc = it }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.password_label), fontSize = 12.sp, color = cs.onSurfaceVariant)
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(stringResource(R.string.password_hint)) },
                    visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showPw = !showPw }) {
                            Icon(if (showPw) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))
                DropField(stringResource(R.string.volume_label), volLabels, volIdx, true, Modifier.fillMaxWidth()) { volIdx = it }
                CheckRow(stringResource(R.string.delete_source), deleteSrc) { deleteSrc = it }
                if (req.files.size > 1) {
                    CheckRow(stringResource(R.string.separate_archives), separate) { separate = it }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    vm.dlg = null
                    vm.createArchive(
                        req.files,
                        ArchiveOptions(
                            name = name, dest = dest, level = level, password = password, enc = enc,
                            volumeBytes = volBytes[volIdx], deleteSource = deleteSrc,
                            separate = separate && req.files.size > 1
                        )
                    )
                },
                enabled = name.isNotBlank()
            ) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun PasswordDialog(vm: FilesViewModel, req: Dlg.Password) {
    var pw by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { vm.dlg = null },
        title = { Text(stringResource(R.string.password_required)) },
        text = {
            Column {
                Text(req.zip.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, singleLine = true,
                    placeholder = { Text(stringResource(R.string.password_hint)) },
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { show = !show }) {
                            Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                        }
                    }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { vm.dlg = null; vm.extractEncrypted(req.zip, req.dest, req.sub, pw) },
                enabled = pw.isNotEmpty()
            ) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.cancel)) } }
    )
}

// ───────────────────────── Pengaturan & lainnya ─────────────────────────

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = value, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
        )
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 14.sp)
    }
}

@Composable
fun PrefsDialog(vm: FilesViewModel) {
    AlertDialog(
        onDismissRequest = { vm.dlg = null },
        title = { Text(stringResource(R.string.settings)) },
        confirmButton = { TextButton(onClick = { vm.dlg = null }) { Text(stringResource(R.string.close)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SwitchRow(stringResource(R.string.pref_dual), vm.dual) { vm.changeDual(it) }
                SwitchRow(stringResource(R.string.pref_hidden), vm.showHidden) { vm.changeHidden(it) }
                SwitchRow(stringResource(R.string.pref_categories), vm.categories) { vm.changeCategories(it) }
                SwitchRow(stringResource(R.string.pref_dark), vm.dark) { vm.changeDark(it) }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.pref_colors), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Palettes.forEachIndexed { i, pal ->
                    RadioRow(stringResource(pal.labelRes), vm.palette == i) { vm.changePalette(i) }
                }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.pref_drop), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                RadioRow(stringResource(R.string.drop_ask), vm.dropMode == 0) { vm.changeDropMode(0) }
                RadioRow(stringResource(R.string.drop_copy), vm.dropMode == 1) { vm.changeDropMode(1) }
                RadioRow(stringResource(R.string.drop_move), vm.dropMode == 2) { vm.changeDropMode(2) }
            }
        }
    )
}

@Composable
fun AboutDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("zenorX 2.1.0") },
        text = { Text(stringResource(R.string.about_text), fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.close)) } }
    )
}

@Composable
fun PropsDialog(vm: FilesViewModel, info: PropsInfo) {
    val f = info.file
    val calc = stringResource(R.string.calculating)
    val rows = listOf(
        stringResource(R.string.prop_name) to f.name.ifEmpty { "/" },
        stringResource(R.string.prop_location) to (f.parent ?: "/"),
        stringResource(R.string.prop_type) to (if (f.isDirectory) stringResource(R.string.folder_word) else mimeOf(f)),
        stringResource(R.string.prop_size) to (info.bytes?.let { "${humanSize(it)} ($it B)" } ?: calc),
        stringResource(R.string.prop_contents) to (info.files?.let { stringResource(R.string.n_files, it) } ?: calc),
        stringResource(R.string.prop_modified) to formatFull(f.lastModified()),
        stringResource(R.string.prop_permissions) to
            ((if (f.canRead()) "r" else "-") + (if (f.canWrite()) "w" else "-") + (if (f.canExecute()) "x" else "-"))
    )
    AlertDialog(
        onDismissRequest = { vm.closeProps() },
        title = { Text(stringResource(R.string.properties)) },
        confirmButton = { TextButton(onClick = { vm.closeProps() }) { Text(stringResource(R.string.close)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                rows.forEach { (k, v) ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Text(k, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, fontSize = 14.sp)
                    }
                }
            }
        }
    )
}

@Composable
fun DropDialog(vm: FilesViewModel, req: DropReq) {
    AlertDialog(
        onDismissRequest = { vm.dropReq = null },
        title = { Text(stringResource(R.string.drop_title)) },
        text = {
            Text(
                (if (req.files.size == 1) "\"${req.files[0].name}\"" else stringResource(R.string.n_items, req.files.size)) +
                    "\n→ ${req.dest.absolutePath}"
            )
        },
        confirmButton = {
            Row {
                TextButton(onClick = {
                    vm.dropReq = null
                    vm.clearSelection()
                    vm.transfer(req.files, req.dest, false)
                }) { Text(stringResource(R.string.copy)) }
                TextButton(onClick = {
                    vm.dropReq = null
                    vm.clearSelection()
                    vm.transfer(req.files, req.dest, true)
                }) { Text(stringResource(R.string.move)) }
            }
        },
        dismissButton = { TextButton(onClick = { vm.dropReq = null }) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun BusyDialog(vm: FilesViewModel, b: Busy) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("${b.title}…") },
        text = {
            Column {
                Text(
                    b.detail.ifEmpty { " " }, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { (b.done.toFloat() / b.total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(6.dp))
                Text("${b.done} / ${b.total}", fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { vm.cancelOp() }) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun CrashDialog(report: String, onClose: () -> Unit) {
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.crash_title)) },
        text = {
            Column(Modifier.height(320.dp).verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.crash_text), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(report, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        },
        confirmButton = {
            TextButton(onClick = { clip.setText(AnnotatedString(report)) }) { Text(stringResource(R.string.copy)) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.close)) } }
    )
}

@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1C1C1C), Color(0xFF000000)))),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.app_logo),
                contentDescription = "zenorX",
                modifier = Modifier.size(96.dp)
            )
            Spacer(Modifier.height(18.dp))
            Text("zenorX", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(
                stringResource(R.string.permission_text),
                color = Color(0xFFD6D6D6), fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = cs.primary)) {
                Text(stringResource(R.string.grant_permission), color = Color.White)
            }
        }
    }
}
