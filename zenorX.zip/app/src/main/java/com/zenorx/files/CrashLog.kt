package com.zenorx.files

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Menyimpan laporan crash terakhir supaya bisa ditampilkan saat aplikasi dibuka lagi. */
object CrashLog {
    private var installed = false

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "last_crash.txt")

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                file(app).writeText(
                    "zenorX | Android " + Build.VERSION.SDK_INT + " | " + Build.MODEL +
                        "\nThread: " + t.name + "\n\n" + sw.toString()
                )
            } catch (x: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? {
        val f = file(ctx)
        return try {
            if (f.exists()) f.readText() else null
        } catch (e: Exception) {
            null
        }
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (e: Exception) {
        }
    }
}
