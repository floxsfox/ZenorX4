package com.zenorx.files

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

// ───────────────────────── Root ─────────────────────────

@Composable
fun ZenorXApp(vm: FilesViewModel) {
    val cs = MaterialTheme.colorScheme
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val act = vm.panel(vm.active)
    val selecting = vm.selecting()
    val barColor = if (vm.dual) DualBarColor else LocalToolbar.current

    val view = LocalView.current
    SideEffect {
        val window = (view.context as Activity).window
        @Suppress("DEPRECATION")
        window.statusBarColor = barColor.toArgb()
    }

    LaunchedEffect(Unit) {
        for (m in vm.messages) {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(m)
        }
    }

    BackHandler(
        enabled = vm.fabOpen || drawer.isOpen || selecting || vm.searchOpen || vm.canGoUp(act)
    ) {
        when {
            vm.fabOpen -> vm.fabOpen = false
            drawer.isOpen -> scope.launch { drawer.close() }
            selecting -> vm.clearSelection()
            vm.searchOpen -> vm.closeSearch()
            else -> vm.up(act)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = !vm.dnd.active,
        drawerContent = { Sidebar(vm) { scope.launch { drawer.close() } } }
    ) {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = cs.background,
                snackbarHost = { SnackbarHost(snack) },
                topBar = { TopBar(vm) { scope.launch { drawer.open() } } },
                bottomBar = { BottomBar(vm) }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    Column(Modifier.fillMaxSize()) {
                        if (vm.searchOpen) SearchBar(vm)
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            FilePanel(vm, vm.panelA, Modifier.weight(1f).fillMaxHeight())
                            if (vm.dual) {
                                Box(Modifier.width(1.dp).fillMaxHeight().background(cs.outline))
                                FilePanel(vm, vm.panelB, Modifier.weight(1f).fillMaxHeight())
                            }
                        }
                    }
                    if (!vm.dual && !selecting) FabMenu(vm, act)
                }
            }
            DragOverlay(vm)
        }
    }
    DialogHost(vm)
}

// ───────────────────────── Toolbar ─────────────────────────

@Composable
fun TopBar(vm: FilesViewModel, onMenu: () -> Unit) {
    val act = vm.panel(vm.active)
    val bg = if (vm.dual) DualBarColor else LocalToolbar.current
    Surface(color = bg, contentColor = Color.White, shadowElevation = 4.dp) {
        if (vm.selecting()) {
            SelectionTop(vm, act)
        } else if (vm.dual) {
            DualTop(vm, act, onMenu)
        } else {
            SingleTop(vm, act)
        }
    }
}

@Composable
private fun SelectionTop(vm: FilesViewModel, p: PanelState) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { vm.clearSelection() }) { Icon(Icons.Filled.Close, stringResource(R.string.cd_clear_selection)) }
        Text(
            stringResource(R.string.n_selected, p.selected.size), fontSize = 19.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = {
            if (p.items.isNotEmpty() && p.selected.size == p.items.size) p.selected = emptySet()
            else vm.selectAll(p)
        }) { Icon(Icons.Filled.SelectAll, stringResource(R.string.select_all)) }
    }
}

@Composable
private fun SingleTop(vm: FilesViewModel, p: PanelState) {
    var pathMenu by remember { mutableStateOf(false) }
    var viewMenu by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { vm.up(p) }) { Icon(Icons.Filled.ArrowBack, stringResource(R.string.cd_up)) }
        Box(Modifier.weight(1f)) {
            Column(
                Modifier.clip(RoundedCornerShape(6.dp)).clickable { pathMenu = true }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Text(
                    p.path.name.ifEmpty { "/" }, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        p.path.parent ?: "", fontSize = 13.sp, color = Color(0xFFD0D0DC),
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Icon(Icons.Filled.ArrowDropDown, null, Modifier.size(20.dp))
                }
            }
            PathMenu(vm, p, pathMenu) { pathMenu = false }
        }
        IconButton(onClick = { vm.toggleSearch() }) { Icon(Icons.Filled.Search, stringResource(R.string.cd_search)) }
        IconButton(onClick = { vm.changeDual(true) }) { Icon(Icons.Filled.ViewColumn, stringResource(R.string.cd_dual)) }
        Box {
            IconButton(onClick = { viewMenu = true }) { Icon(Icons.Filled.ViewModule, stringResource(R.string.cd_view)) }
            DropdownMenu(expanded = viewMenu, onDismissRequest = { viewMenu = false }) {
                ViewOptionsContent(vm)
            }
        }
        Box {
            IconButton(onClick = { more = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.more)) }
            OverflowMenu(vm, p, more) { more = false }
        }
    }
}

@Composable
private fun DualTop(vm: FilesViewModel, p: PanelState, onMenu: () -> Unit) {
    var more by remember { mutableStateOf(false) }
    val folders = p.items.count { it.isDir }
    val files = p.items.size - folders
    val storage = remember(p.path) { storageText(p.path) }
    val pathText = p.path.absolutePath.let { if (it.endsWith("/")) it else "$it/" }
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, stringResource(R.string.cd_menu)) }
        Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
            Text(
                pathText, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                stringResource(R.string.dual_stats, folders, files, storage), fontSize = 11.sp,
                color = Color(0xFFBDBDBD), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = { vm.toggleSearch() }) { Icon(Icons.Filled.Search, stringResource(R.string.cd_search)) }
        IconButton(onClick = { vm.changeDual(false) }) {
            Icon(Icons.Filled.ViewColumn, stringResource(R.string.dual_off), tint = MaterialTheme.colorScheme.primary)
        }
        Box {
            IconButton(onClick = { more = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.more)) }
            OverflowMenu(vm, p, more) { more = false }
        }
    }
}

@Composable
private fun PathMenu(vm: FilesViewModel, p: PanelState, expanded: Boolean, onDismiss: () -> Unit) {
    val crumbs = remember(p.path) { vm.crumbs(p.path) }
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        crumbs.reversed().forEach { c ->
            DropdownMenuItem(
                text = { Text(c.first.ifEmpty { "/" }) },
                leadingIcon = { Icon(Icons.Filled.Folder, null) },
                onClick = { onDismiss(); vm.navigate(p, c.second) }
            )
        }
        DropdownMenuItem(
            text = { Text(stringResource(R.string.storage_internal)) },
            leadingIcon = { Icon(Icons.Filled.Storage, null) },
            onClick = { onDismiss(); vm.navigate(p, vm.root) }
        )
        vm.sdCards.forEach { sd ->
            DropdownMenuItem(
                text = { Text(stringResource(R.string.sd_card, sd.name)) },
                leadingIcon = { Icon(Icons.Filled.SdCard, null) },
                onClick = { onDismiss(); vm.navigate(p, sd) }
            )
        }
    }
}

@Composable
private fun MenuItem(icon: ImageVector, label: String, indent: Boolean = false, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label, modifier = Modifier.padding(start = if (indent) 20.dp else 0.dp)) },
        leadingIcon = { Icon(icon, null) },
        onClick = onClick
    )
}

@Composable
private fun OverflowMenu(vm: FilesViewModel, p: PanelState, expanded: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var create by remember { mutableStateOf(false) }
    val clip = vm.clip
    DropdownMenu(expanded = expanded, onDismissRequest = { create = false; onDismiss() }) {
        MenuItem(Icons.Filled.DoneAll, stringResource(R.string.menu_select_multi)) { onDismiss(); vm.multi = true }
        MenuItem(Icons.Filled.AddCircleOutline, stringResource(R.string.create)) { create = !create }
        if (create) {
            MenuItem(Icons.Filled.CreateNewFolder, stringResource(R.string.folder_word), true) {
                create = false; onDismiss(); vm.dlg = Dlg.NewFolder(p.path)
            }
            MenuItem(Icons.Filled.NoteAdd, stringResource(R.string.file_word), true) {
                create = false; onDismiss(); vm.dlg = Dlg.NewFile(p.path)
            }
        }
        if (clip != null) {
            MenuItem(Icons.Filled.ContentPaste, stringResource(R.string.paste_n, clip.files.size)) { onDismiss(); vm.paste(p) }
        }
        if (vm.dual) {
            MenuItem(Icons.Filled.ViewModule, stringResource(R.string.view_and_sort)) { onDismiss(); vm.dlg = Dlg.ViewOpts }
        }
        MenuItem(
            Icons.Filled.ViewColumn,
            if (vm.dual) stringResource(R.string.dual_off) else stringResource(R.string.dual_on)
        ) { onDismiss(); vm.changeDual(!vm.dual) }
        MenuItem(Icons.Filled.Settings, stringResource(R.string.settings)) { onDismiss(); vm.dlg = Dlg.Prefs }
        MenuItem(Icons.Filled.Info, stringResource(R.string.about)) { onDismiss(); vm.dlg = Dlg.About }
        MenuItem(Icons.Filled.ExitToApp, stringResource(R.string.exit)) { onDismiss(); (ctx as? Activity)?.finish() }
    }
}

@Composable
fun SearchBar(vm: FilesViewModel) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val hint = if (vm.dual) stringResource(R.string.search_hint_panel, if (vm.active == 0) "A" else "B") else stringResource(R.string.search_hint)
    Row(
        Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = vm.searchText,
            onValueChange = { vm.searchText = it },
            modifier = Modifier.weight(1f).focusRequester(focus),
            singleLine = true,
            placeholder = { Text(hint, fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(vm.panel(vm.active), vm.searchText) })
        )
        IconButton(onClick = { vm.closeSearch() }) { Icon(Icons.Filled.Close, stringResource(R.string.cd_close_search)) }
    }
}

// ───────────────────────── Tombol + (gaya ZArchiver) ─────────────────────────

@Composable
fun BoxScope.FabMenu(vm: FilesViewModel, p: PanelState) {
    val cs = MaterialTheme.colorScheme
    val pickMsg = stringResource(R.string.t_pick_files_for_archive)
    if (vm.fabOpen) {
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { vm.fabOpen = false }
        )
    }
    Column(
        Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (vm.fabOpen) {
            val clip = vm.clip
            if (clip != null) {
                MiniFab(Icons.Filled.ContentPaste, stringResource(R.string.paste_n, clip.files.size)) {
                    vm.fabOpen = false; vm.paste(p)
                }
            }
            MiniFab(Icons.Filled.Archive, stringResource(R.string.new_archive)) {
                vm.fabOpen = false
                val sel = vm.selectedFiles(p)
                if (sel.isEmpty()) {
                    vm.multi = true
                    vm.toast(pickMsg)
                } else {
                    vm.dlg = Dlg.CreateArchive(sel, p.path)
                }
            }
            MiniFab(Icons.Filled.Description, stringResource(R.string.new_file)) {
                vm.fabOpen = false; vm.dlg = Dlg.NewFile(p.path)
            }
            MiniFab(Icons.Filled.Folder, stringResource(R.string.new_folder)) {
                vm.fabOpen = false; vm.dlg = Dlg.NewFolder(p.path)
            }
        }
        FloatingActionButton(
            onClick = { vm.fabOpen = !vm.fabOpen },
            shape = CircleShape,
            containerColor = cs.primary,
            contentColor = Color.White
        ) {
            Icon(if (vm.fabOpen) Icons.Filled.Close else Icons.Filled.Add, stringResource(R.string.create))
        }
    }
}

@Composable
private fun MiniFab(icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(6.dp), color = Color(0xCC000000)) {
            Text(
                label, color = Color.White, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        Spacer(Modifier.width(10.dp))
        FloatingActionButton(
            onClick = onClick,
            shape = CircleShape,
            containerColor = cs.primary,
            contentColor = Color.White,
            modifier = Modifier.size(44.dp)
        ) { Icon(icon, label, Modifier.size(22.dp)) }
    }
}

// ───────────────────────── Bar bawah ─────────────────────────

@Composable
fun BottomBar(vm: FilesViewModel) {
    if (vm.selecting()) {
        SelectionBar(vm)
    } else if (vm.dual) {
        DualBottomBar(vm)
    }
}

@Composable
private fun BarIcon(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme.onSurface
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(icon, null, tint = if (enabled) c else c.copy(alpha = 0.35f))
    }
}

/** Toolbar bawah ala MT Manager: mundur, maju, +, tukar, naik. */
@Composable
private fun DualBottomBar(vm: FilesViewModel) {
    val cs = MaterialTheme.colorScheme
    val p = vm.panel(vm.active)
    val clip = vm.clip
    var plus by remember { mutableStateOf(false) }
    var swap by remember { mutableStateOf(false) }
    val other = if (vm.active == 0) "B" else "A"
    Surface(color = cs.surface, shadowElevation = 10.dp) {
        Row(
            Modifier.fillMaxWidth().height(56.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BarIcon(Icons.Filled.KeyboardArrowLeft, p.canBack) { vm.goBack(p) }
            BarIcon(Icons.Filled.KeyboardArrowRight, p.canForward) { vm.goForward(p) }
            Box {
                BarIcon(Icons.Filled.Add, true) { plus = true }
                DropdownMenu(expanded = plus, onDismissRequest = { plus = false }) {
                    MenuItem(Icons.Filled.CreateNewFolder, stringResource(R.string.new_folder)) {
                        plus = false; vm.dlg = Dlg.NewFolder(p.path)
                    }
                    MenuItem(Icons.Filled.NoteAdd, stringResource(R.string.new_file)) {
                        plus = false; vm.dlg = Dlg.NewFile(p.path)
                    }
                    if (clip != null) {
                        MenuItem(Icons.Filled.ContentPaste, stringResource(R.string.paste_n, clip.files.size)) {
                            plus = false; vm.paste(p)
                        }
                    }
                }
            }
            Box {
                BarIcon(Icons.Filled.SwapHoriz, true) { swap = true }
                DropdownMenu(expanded = swap, onDismissRequest = { swap = false }) {
                    MenuItem(Icons.Filled.ContentCopy, stringResource(R.string.copy_to_panel, other)) {
                        swap = false; vm.transferToOther(false)
                    }
                    MenuItem(Icons.Filled.ContentCut, stringResource(R.string.move_to_panel, other)) {
                        swap = false; vm.transferToOther(true)
                    }
                    MenuItem(Icons.Filled.SwapHoriz, stringResource(R.string.swap_folders)) { swap = false; vm.swapPanels() }
                    MenuItem(Icons.Filled.ViewColumn, stringResource(R.string.sync_panel, other)) {
                        swap = false; vm.syncPanels()
                    }
                }
            }
            BarIcon(Icons.Filled.ArrowUpward, vm.canGoUp(p)) { vm.up(p) }
        }
    }
}

@Composable
private fun SelAction(icon: ImageVector, label: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme.onSurface
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 8.dp).alpha(if (enabled) 1f else 0.35f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = c, modifier = Modifier.size(22.dp))
        Text(label, fontSize = 10.sp, color = c, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SelectionBar(vm: FilesViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val p = vm.panel(vm.active)
    val sel = vm.selectedFiles(p)
    val n = sel.size
    val clip = vm.clip
    val other = if (vm.active == 0) "B" else "A"
    var more by remember { mutableStateOf(false) }
    Surface(color = cs.surface, shadowElevation = 10.dp) {
        Row(Modifier.fillMaxWidth().height(62.dp), verticalAlignment = Alignment.CenterVertically) {
            if (vm.dual) {
                SelAction(Icons.Filled.ContentCopy, stringResource(R.string.copy_arrow, other), n > 0, Modifier.weight(1f)) {
                    vm.transferToOther(false)
                }
                SelAction(Icons.Filled.SwapHoriz, stringResource(R.string.move_arrow, other), n > 0, Modifier.weight(1f)) {
                    vm.transferToOther(true)
                }
            } else {
                SelAction(Icons.Filled.ContentCopy, stringResource(R.string.copy), n > 0, Modifier.weight(1f)) { vm.copyToClip(p, false) }
                SelAction(Icons.Filled.ContentCut, stringResource(R.string.cut), n > 0, Modifier.weight(1f)) { vm.copyToClip(p, true) }
            }
            SelAction(Icons.Filled.Delete, stringResource(R.string.delete), n > 0, Modifier.weight(1f)) { vm.dlg = Dlg.Delete(sel) }
            SelAction(Icons.Filled.Archive, stringResource(R.string.compress), n > 0, Modifier.weight(1f)) { vm.dlg = Dlg.CreateArchive(sel, p.path) }
            Box(Modifier.weight(1f)) {
                SelAction(Icons.Filled.MoreVert, stringResource(R.string.more), true, Modifier.fillMaxWidth()) { more = true }
                DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                    if (vm.dual) {
                        MenuItem(Icons.Filled.ContentCopy, stringResource(R.string.copy_clip)) {
                            more = false; vm.copyToClip(p, false)
                        }
                        MenuItem(Icons.Filled.ContentCut, stringResource(R.string.cut_clip)) {
                            more = false; vm.copyToClip(p, true)
                        }
                    }
                    if (clip != null) {
                        MenuItem(Icons.Filled.ContentPaste, stringResource(R.string.paste_n, clip.files.size)) {
                            more = false; vm.paste(p)
                        }
                    }
                    if (n == 1) {
                        MenuItem(Icons.Filled.Edit, stringResource(R.string.rename)) { more = false; vm.dlg = Dlg.Rename(sel[0]) }
                    }
                    if (n == 1 && sel[0].isFile && sel[0].extension.lowercase() in extractableExt) {
                        MenuItem(Icons.Filled.Unarchive, stringResource(R.string.extract_to, sel[0].nameWithoutExtension)) {
                            more = false; vm.extractFolder(sel[0], p.path)
                        }
                    }
                    if (n > 0) {
                        MenuItem(Icons.Filled.Share, stringResource(R.string.share)) { more = false; vm.share(ctx, sel) }
                        MenuItem(Icons.Filled.Info, stringResource(R.string.properties)) { more = false; vm.showProps(sel[0]) }
                    }
                    MenuItem(Icons.Filled.SelectAll, stringResource(R.string.select_all)) { more = false; vm.selectAll(p) }
                }
            }
        }
    }
}

// ───────────────────────── Sidebar ─────────────────────────

class Place(val labelRes: Int, val icon: ImageVector, val dir: File)

fun placesOf(vm: FilesViewModel): List<Place> {
    val r = vm.root
    return listOf(
        Place(R.string.place_home, Icons.Filled.Home, r),
        Place(R.string.place_documents, Icons.Filled.Description, File(r, "Documents")),
        Place(R.string.place_downloads, Icons.Filled.Download, File(r, "Download")),
        Place(R.string.place_music, Icons.Filled.MusicNote, File(r, "Music")),
        Place(R.string.place_pictures, Icons.Filled.Image, File(r, "Pictures")),
        Place(R.string.place_videos, Icons.Filled.Movie, File(r, "Movies")),
        Place(R.string.place_camera, Icons.Filled.CameraAlt, File(r, "DCIM"))
    ).filter { it.dir.isDirectory }
}

@Composable
fun Sidebar(vm: FilesViewModel, close: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val p = vm.panel(vm.active)
    val places = remember { placesOf(vm) }
    ModalDrawerSheet(drawerContainerColor = cs.surface) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(LocalToolbar.current, Color(0xFF1B0013))))
                    .padding(20.dp)
            ) {
                Column {
                    Image(
                        painter = painterResource(R.drawable.app_logo),
                        contentDescription = "zenorX",
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("zenorX", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.tagline), color = Color(0xFFD9B8CF), fontSize = 12.sp)
                }
            }
            SectionLabel(stringResource(R.string.places))
            places.forEach { pl ->
                DrawerItem(stringResource(pl.labelRes), pl.icon, p.path == pl.dir) { vm.navigate(p, pl.dir); close() }
            }
            SectionLabel(stringResource(R.string.devices))
            DrawerItem(stringResource(R.string.storage_internal), Icons.Filled.Storage, p.path == vm.root) {
                vm.navigate(p, vm.root); close()
            }
            vm.sdCards.forEach { sd ->
                DrawerItem(stringResource(R.string.sd_card, sd.name), Icons.Filled.SdCard, p.path == sd) {
                    vm.navigate(p, sd); close()
                }
            }
            DrawerItem(stringResource(R.string.root_system), Icons.Filled.Folder, p.path.absolutePath == "/") {
                vm.navigate(p, File("/")); close()
            }
            SectionLabel(stringResource(R.string.app_section))
            DrawerItem(stringResource(R.string.settings), Icons.Filled.Settings, false) { vm.dlg = Dlg.Prefs; close() }
            DrawerItem(stringResource(R.string.about), Icons.Filled.Info, false) { vm.dlg = Dlg.About; close() }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SectionLabel(t: String) {
    Text(
        t.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 24.dp, top = 14.dp, bottom = 4.dp)
    )
}

@Composable
private fun DrawerItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    NavigationDrawerItem(
        label = { Text(label, fontSize = 14.sp) },
        icon = { Icon(icon, null) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = cs.primary.copy(alpha = 0.25f),
            selectedIconColor = cs.primary,
            selectedTextColor = cs.primary
        )
    )
}

// ───────────────────────── Overlay drag ─────────────────────────

@Composable
fun DragOverlay(vm: FilesViewModel) {
    val d = vm.dnd
    if (!d.active) return
    val label = if (d.files.size == 1) d.files[0].name else stringResource(R.string.n_items, d.files.size)
    Surface(
        modifier = Modifier.offset { IntOffset((d.pos.x - 40f).roundToInt(), (d.pos.y - 100f).roundToInt()) },
        color = MaterialTheme.colorScheme.primary,
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 10.dp
    ) {
        Row(
            Modifier.widthIn(max = 220.dp).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (d.files.size == 1 && d.files[0].isDirectory) Icons.Filled.Folder else Icons.Filled.Description,
                null, tint = Color.White, modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
