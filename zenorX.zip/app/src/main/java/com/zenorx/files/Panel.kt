package com.zenorx.files

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class RectHolder {
    var rect: Rect = Rect.Zero
}

class Origin {
    var x = 0f
    var y = 0f
}

// ───────────────────────── ikon & warna per jenis ─────────────────────────

fun iconFor(k: FileKind): ImageVector = when (k) {
    FileKind.FOLDER -> Icons.Filled.Folder
    FileKind.IMAGE -> Icons.Filled.Image
    FileKind.AUDIO -> Icons.Filled.Audiotrack
    FileKind.VIDEO -> Icons.Filled.Movie
    FileKind.ARCHIVE -> Icons.Filled.Archive
    FileKind.APK -> Icons.Filled.Android
    FileKind.CODE -> Icons.Filled.Code
    FileKind.PDF -> Icons.Filled.PictureAsPdf
    FileKind.TEXT -> Icons.Filled.Description
    FileKind.OTHER -> Icons.Filled.Description
}

fun colorFor(k: FileKind): Color = when (k) {
    FileKind.FOLDER -> Color(0xFFFFA726)
    FileKind.IMAGE -> Color(0xFF5BB974)
    FileKind.AUDIO -> Color(0xFF8E4B9C)
    FileKind.VIDEO -> Color(0xFFD9534F)
    FileKind.ARCHIVE -> Color(0xFFD9A62E)
    FileKind.APK -> Color(0xFF7CB342)
    FileKind.CODE -> Color(0xFF4A90D9)
    FileKind.PDF -> Color(0xFFD9534F)
    FileKind.TEXT -> Color(0xFF7D8793)
    FileKind.OTHER -> Color(0xFF777777)
}

fun folderOverlay(name: String): ImageVector? = when (name.lowercase()) {
    "dcim", "camera" -> Icons.Filled.CameraAlt
    "documents" -> Icons.Filled.Work
    "download", "downloads" -> Icons.Filled.Download
    "android" -> Icons.Filled.Android
    "alarms" -> Icons.Filled.Alarm
    "music" -> Icons.Filled.MusicNote
    "pictures" -> Icons.Filled.Image
    "movies" -> Icons.Filled.Movie
    else -> null
}

// ───────────────────────── thumbnail asinkron ─────────────────────────

@Composable
fun rememberThumb(item: FileItem): Thumb? {
    if (!Thumbs.wants(item.kind)) return null
    val ctx = LocalContext.current.applicationContext
    val st = produceState<Thumb?>(Thumbs.peek(item), item.path, item.modified) {
        if (value == null) value = Thumbs.load(ctx, item)
    }
    return st.value
}

@Composable
fun rememberCount(item: FileItem): Int? {
    if (!item.isDir) return null
    val st = produceState<Int?>(Thumbs.peekCount(item), item.path, item.modified) {
        if (value == null) value = Thumbs.count(item)
    }
    return st.value
}

// ───────────────────────── glyph ─────────────────────────

@Composable
fun FolderGlyph(sz: Dp, overlay: ImageVector?, overlayTint: Color = Color.White) {
    Box(Modifier.size(sz), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRoundRect(
                color = Color(0xFFF59A1B),
                topLeft = Offset(0f, h * 0.10f),
                size = Size(w * 0.46f, h * 0.34f),
                cornerRadius = CornerRadius(w * 0.07f, w * 0.07f)
            )
            drawRoundRect(
                color = Color(0xFFFFA726),
                topLeft = Offset(0f, h * 0.24f),
                size = Size(w, h * 0.66f),
                cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
            )
            drawRect(
                color = Color(0xCCFFFFFF),
                topLeft = Offset(w * 0.12f, h * 0.36f),
                size = Size(w * 0.26f, h * 0.045f)
            )
        }
        if (overlay != null) {
            Icon(
                overlay, null, tint = overlayTint,
                modifier = Modifier.size(sz * 0.36f).offset(y = sz * 0.12f)
            )
        }
    }
}

@Composable
fun SquareGlyph(icon: ImageVector, tint: Color, sz: Dp) {
    Box(
        Modifier.size(sz).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B1B1B)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(sz * 0.6f))
    }
}

@Composable
fun PageGlyph(kind: FileKind, sz: Dp) {
    Box(
        Modifier.size(sz * 0.8f, sz).clip(RoundedCornerShape(5.dp)).background(colorFor(kind)),
        contentAlignment = Alignment.Center
    ) {
        Icon(iconFor(kind), null, tint = Color.White.copy(alpha = 0.92f), modifier = Modifier.size(sz * 0.5f))
    }
}

/** Ikon file/folder: thumbnail kalau ada, kalau tidak glyph sesuai jenis. */
@Composable
fun IconBox(item: FileItem, thumb: Thumb?, selected: Boolean, dual: Boolean, sz: Dp) {
    val cs = MaterialTheme.colorScheme
    val img = thumb?.image
    Box(Modifier.size(sz), contentAlignment = Alignment.Center) {
        if (selected) {
            Box(
                Modifier.size(sz * 0.8f).background(cs.primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(sz * 0.45f))
            }
        } else if (item.isDir) {
            if (dual) SquareGlyph(Icons.Filled.Folder, Color(0xFFE6E6E6), sz)
            else FolderGlyph(sz, folderOverlay(item.name))
        } else if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(sz).clip(RoundedCornerShape(6.dp))
            )
        } else {
            if (dual) SquareGlyph(iconFor(item.kind), colorFor(item.kind), sz)
            else PageGlyph(item.kind, sz)
        }
    }
}

// ───────────────────────── gestur: ketuk / tahan lama + seret ─────────────────────────

@Composable
fun Modifier.fileGestures(vm: FilesViewModel, p: PanelState, path: String): Modifier {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val origin = remember { Origin() }
    return this
        .onGloballyPositioned { c ->
            val o = c.positionInRoot()
            origin.x = o.x
            origin.y = o.y
        }
        .pointerInput(path) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                var outcome = 0 // 0 = tahan lama, 1 = ketuk, 2 = batal/scroll
                withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                    val up = waitForUpOrCancellation()
                    outcome = if (up != null) 1 else 2
                    up?.consume()
                }
                if (outcome == 1) {
                    vm.onRowTap(p, path, ctx)
                } else if (outcome == 0) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    vm.dragStart(p, path, Offset(origin.x + down.position.x, origin.y + down.position.y))
                    val ok = drag(down.id) { change ->
                        change.consume()
                        vm.dragMove(Offset(origin.x + change.position.x, origin.y + change.position.y))
                    }
                    if (ok) vm.dragEnd() else vm.dragCancel()
                }
            }
        }
}

// ───────────────────────── baris ─────────────────────────

@Composable
fun ParentRow(vm: FilesViewModel, p: PanelState, dual: Boolean, hovered: Boolean) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth()
            .height(if (dual) 54.dp else 56.dp)
            .background(if (hovered) cs.primary.copy(alpha = 0.35f) else Color.Transparent)
            .clickable { vm.activate(p); vm.up(p) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(8.dp))
        if (dual) SquareGlyph(Icons.Filled.Folder, Color(0xFFE6E6E6), 40.dp)
        else FolderGlyph(44.dp, Icons.Filled.ArrowUpward, Color(0xFF5E8C1F))
        Spacer(Modifier.width(12.dp))
        Text("..", fontSize = 16.sp, color = cs.onSurface)
    }
}

@Composable
fun FileRow(
    vm: FilesViewModel,
    p: PanelState,
    item: FileItem,
    selected: Boolean,
    hovered: Boolean,
    dual: Boolean,
    compact: Boolean
) {
    val cs = MaterialTheme.colorScheme
    val thumb = rememberThumb(item)
    val count = rememberCount(item)
    val bg = when {
        hovered -> cs.primary.copy(alpha = 0.35f)
        selected -> cs.primary.copy(alpha = 0.22f)
        else -> Color.Transparent
    }
    val iconSize = if (compact) 30.dp else if (dual) 40.dp else 44.dp
    val rowH = if (compact) 44.dp else if (dual) 58.dp else 60.dp
    val sub = when {
        p.resultsMode -> item.file.parent ?: ""
        dual -> formatMt(item.modified) + (if (item.isDir) "" else "  " + humanSize(item.size))
        item.isDir -> if (count != null) stringResource(R.string.n_items, count) else "…"
        else -> humanSize(item.size) + (thumb?.extra?.let { " • $it" } ?: "")
    }
    Row(
        Modifier.fillMaxWidth().height(rowH).background(bg).fileGestures(vm, p, item.path),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(8.dp))
        IconBox(item, thumb, selected, dual, iconSize)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name,
                fontSize = if (compact) 14.sp else if (dual) 15.sp else 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurface
            )
            if (!compact) {
                Text(
                    sub, fontSize = 12.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                )
            }
        }
        if (!dual) {
            Text(
                if (compact) sub else formatShort(item.modified),
                fontSize = 12.sp, maxLines = 1, color = cs.onSurfaceVariant,
                modifier = Modifier
                    .padding(start = 6.dp, end = 12.dp)
                    .align(if (compact) Alignment.CenterVertically else Alignment.Bottom)
                    .padding(bottom = if (compact) 0.dp else 10.dp)
            )
        }
    }
}

@Composable
fun GridCell(vm: FilesViewModel, p: PanelState, item: FileItem, selected: Boolean, hovered: Boolean) {
    val cs = MaterialTheme.colorScheme
    val thumb = rememberThumb(item)
    val bg = when {
        hovered -> cs.primary.copy(alpha = 0.35f)
        selected -> cs.primary.copy(alpha = 0.22f)
        else -> Color.Transparent
    }
    Column(
        Modifier.padding(3.dp).clip(RoundedCornerShape(8.dp)).background(bg)
            .fileGestures(vm, p, item.path).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconBox(item, thumb, selected, false, 56.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            item.name, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, color = cs.onSurface
        )
    }
}

@Composable
fun GridParent(vm: FilesViewModel, p: PanelState, hovered: Boolean) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.padding(3.dp).clip(RoundedCornerShape(8.dp))
            .background(if (hovered) cs.primary.copy(alpha = 0.35f) else Color.Transparent)
            .clickable { vm.activate(p); vm.up(p) }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FolderGlyph(56.dp, Icons.Filled.ArrowUpward, Color(0xFF5E8C1F))
        Spacer(Modifier.height(4.dp))
        Text("..", fontSize = 12.sp, color = cs.onSurface)
    }
}

// ───────────────────────── kategori: Folder / File / Arsip ─────────────────────────

sealed class ListRow(val key: String) {
    class Header(val titleRes: Int, val count: Int) : ListRow("hdr_$titleRes")
    class Entry(val item: FileItem) : ListRow(item.path)
}

/** Sisipkan judul seksi: Folder, lalu File, lalu Arsip (urutan sudah diatur oleh sortItems). */
fun buildRows(items: List<FileItem>, categories: Boolean): List<ListRow> {
    if (!categories) return items.map { ListRow.Entry(it) }
    var dirs = 0
    var archives = 0
    for (x in items) {
        if (x.isDir) dirs++ else if (x.kind == FileKind.ARCHIVE) archives++
    }
    val files = items.size - dirs - archives
    val out = ArrayList<ListRow>(items.size + 3)
    var last = -1
    for (x in items) {
        val g = if (x.isDir) 0 else if (x.kind == FileKind.ARCHIVE) 2 else 1
        if (g != last) {
            last = g
            when (g) {
                0 -> out.add(ListRow.Header(R.string.cat_folders, dirs))
                1 -> out.add(ListRow.Header(R.string.cat_files, files))
                else -> out.add(ListRow.Header(R.string.cat_archives, archives))
            }
        }
        out.add(ListRow.Entry(x))
    }
    return out
}

@Composable
fun SectionHeader(titleRes: Int, count: Int) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            stringResource(titleRes).uppercase(), fontSize = 11.sp,
            fontWeight = FontWeight.Bold, color = cs.primary, maxLines = 1
        )
        Text("  $count", fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1)
        Box(
            Modifier.weight(1f).padding(start = 8.dp).height(1.dp)
                .background(cs.outline.copy(alpha = 0.6f))
        )
    }
}

// ───────────────────────── panel ─────────────────────────

@Composable
fun FilePanel(vm: FilesViewModel, p: PanelState, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val active = vm.active == p.id
    val dual = vm.dual
    val grid = vm.viewMode == ViewMode.GRID
    val compact = vm.viewMode == ViewMode.COMPACT
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val holder = remember { RectHolder() }
    val rows = remember(p.items, vm.categories) { buildRows(p.items, vm.categories) }

    LaunchedEffect(p.path) {
        listState.scrollToItem(0)
        gridState.scrollToItem(0)
    }
    DisposableEffect(p.id) {
        onDispose {
            vm.panelBounds.remove(p.id)
            vm.hitTesters.remove(p.id)
        }
    }
    // Hit-test target drop (folder / "..") berdasarkan posisi item yang terlihat, tanpa melacak tiap baris.
    SideEffect {
        vm.hitTesters[p.id] = { pos: Offset ->
            val r = holder.rect
            val x = pos.x - r.left
            val y = pos.y - r.top
            val key: Any? = if (grid) {
                gridState.layoutInfo.visibleItemsInfo.firstOrNull {
                    x >= it.offset.x && x < it.offset.x + it.size.width &&
                        y >= it.offset.y && y < it.offset.y + it.size.height
                }?.key
            } else {
                listState.layoutInfo.visibleItemsInfo.firstOrNull {
                    y >= it.offset && y < it.offset + it.size
                }?.key
            }
            key as? String
        }
    }

    Column(
        modifier
            .onGloballyPositioned { vm.panelBounds[p.id] = it.boundsInRoot() }
            .pointerInput(p.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    vm.activate(p)
                }
            }
            .background(if (dual) cs.surface else cs.background)
    ) {
        if (dual) {
            Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) cs.primary else Color.Transparent))
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { holder.rect = it.boundsInRoot() }
        ) {
            val showParent = p.resultsMode || p.path.parentFile != null
            val parentHover = vm.dnd.active && vm.dnd.hoverPanel == p.id && vm.dnd.hoverFolder == ".."
            if (grid) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (dual) 84.dp else 96.dp),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = if (dual) 8.dp else 96.dp)
                ) {
                    if (showParent) {
                        item(key = "..") { GridParent(vm, p, parentHover) }
                    }
                    gridItems(
                        rows,
                        key = { it.key },
                        span = { row ->
                            if (row is ListRow.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1)
                        }
                    ) { row ->
                        when (row) {
                            is ListRow.Header -> SectionHeader(row.titleRes, row.count)
                            is ListRow.Entry -> {
                                val item = row.item
                                val hovered = vm.dnd.active && vm.dnd.hoverPanel == p.id && vm.dnd.hoverFolder == item.path
                                GridCell(vm, p, item, item.path in p.selected, hovered)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    if (showParent) {
                        item(key = "..") { ParentRow(vm, p, dual, parentHover) }
                    }
                    items(rows, key = { it.key }) { row ->
                        when (row) {
                            is ListRow.Header -> SectionHeader(row.titleRes, row.count)
                            is ListRow.Entry -> {
                                val item = row.item
                                val hovered = vm.dnd.active && vm.dnd.hoverPanel == p.id && vm.dnd.hoverFolder == item.path
                                FileRow(vm, p, item, item.path in p.selected, hovered, dual, compact)
                            }
                        }
                    }
                    item(key = "__end") { Spacer(Modifier.height(if (dual) 8.dp else 96.dp)) }
                }
            }
            if (p.items.isEmpty() && !p.loading) {
                Text(
                    stringResource(
                        if (p.unreadable) R.string.folder_unreadable
                        else if (p.resultsMode) R.string.no_results
                        else R.string.empty_folder
                    ),
                    modifier = Modifier.align(Alignment.Center).padding(top = 80.dp, start = 16.dp, end = 16.dp),
                    color = cs.onSurfaceVariant, fontSize = 14.sp, textAlign = TextAlign.Center
                )
            }
            if (p.loading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    color = cs.primary
                )
            }
            val dropHere = vm.dnd.active && vm.dnd.hoverPanel == p.id &&
                vm.dnd.hoverFolder == null && vm.dnd.from != p.id
            if (dropHere) Box(Modifier.fillMaxSize().border(3.dp, cs.primary))
        }
    }
}
