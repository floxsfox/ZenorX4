package com.zenorx.files

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod

object FileOps {

    fun isLink(f: File): Boolean = try {
        Files.isSymbolicLink(f.toPath())
    } catch (e: Exception) {
        false
    }

    /** Nama unik: "nama (1).ext" jika sudah ada. */
    fun uniqueTarget(dir: File, name: String): File {
        val first = File(dir, name)
        if (!first.exists()) return first
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        var t = File(dir, "$base ($i)$ext")
        while (t.exists()) {
            i++
            t = File(dir, "$base ($i)$ext")
        }
        return t
    }

    fun countFiles(f: File): Int {
        if (f.isDirectory && !isLink(f)) {
            var n = 0
            f.listFiles()?.forEach { n += countFiles(it) }
            return n
        }
        return 1
    }

    private suspend fun copyStream(src: File, dst: File) {
        try {
            src.inputStream().use { input ->
                dst.outputStream().use { output ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
        } catch (e: Throwable) {
            dst.delete()
            throw e
        }
    }

    suspend fun copy(src: File, dstDir: File, onFile: (String) -> Unit): File {
        currentCoroutineContext().ensureActive()
        val target = uniqueTarget(dstDir, src.name)
        if (src.isDirectory && !isLink(src)) {
            if (!target.mkdirs() && !target.isDirectory) throw IOException("Could not create folder ${target.name}")
            src.listFiles()?.forEach { copy(it, target, onFile) }
        } else {
            copyStream(src, target)
            target.setLastModified(src.lastModified())
            onFile(src.name)
        }
        return target
    }

    suspend fun move(src: File, dstDir: File, onFile: (String) -> Unit) {
        currentCoroutineContext().ensureActive()
        val target = uniqueTarget(dstDir, src.name)
        if (src.renameTo(target)) {
            onFile(src.name)
            return
        }
        copy(src, dstDir, onFile)
        delete(src) { }
    }

    suspend fun delete(f: File, onFile: (String) -> Unit) {
        currentCoroutineContext().ensureActive()
        val isRealDir = f.isDirectory && !isLink(f)
        if (isRealDir) f.listFiles()?.forEach { delete(it, onFile) }
        if (!f.delete() && f.exists()) throw IOException("Could not delete ${f.name}")
        if (!isRealDir) onFile(f.name)
    }

    /** Level UI (0 simpan, 1 tercepat, 2 cepat, 3 normal, 4 maksimum) -> level Deflater. */
    fun javaLevel(ui: Int): Int = when (ui) {
        0 -> 0
        1 -> 1
        2 -> 3
        3 -> 6
        else -> 9
    }

    suspend fun zip(files: List<File>, out: File, level: Int, onFile: (String) -> Unit) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            zos.setLevel(level)
            for (f in files) addToZip(zos, f, f.name, out, onFile)
        }
    }

    /** Arsip zip berkata sandi (ZipCrypto / AES) lewat zip4j. */
    suspend fun zipEncrypted(
        files: List<File>, out: File, password: String, level: Int, enc: Int, onFile: (String) -> Unit
    ) {
        val zf = net.lingala.zip4j.ZipFile(out, password.toCharArray())
        val p = ZipParameters()
        if (level <= 0) {
            p.setCompressionMethod(CompressionMethod.STORE)
        } else {
            p.setCompressionMethod(CompressionMethod.DEFLATE)
            p.setCompressionLevel(
                when (level) {
                    1 -> CompressionLevel.FASTEST
                    2 -> CompressionLevel.FAST
                    3 -> CompressionLevel.NORMAL
                    else -> CompressionLevel.MAXIMUM
                }
            )
        }
        p.setEncryptFiles(true)
        when (enc) {
            0 -> p.setEncryptionMethod(EncryptionMethod.ZIP_STANDARD)
            1 -> {
                p.setEncryptionMethod(EncryptionMethod.AES)
                p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_128)
            }
            else -> {
                p.setEncryptionMethod(EncryptionMethod.AES)
                p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256)
            }
        }
        for (f in files) {
            currentCoroutineContext().ensureActive()
            if (f.isDirectory) zf.addFolder(f, p) else zf.addFile(f, p)
            onFile(f.name)
        }
    }

    fun isEncrypted(zip: File): Boolean = try {
        net.lingala.zip4j.ZipFile(zip).isEncrypted()
    } catch (e: Exception) {
        false
    }

    fun headerCount(zip: File): Int = try {
        net.lingala.zip4j.ZipFile(zip).getFileHeaders().size
    } catch (e: Exception) {
        1
    }

    suspend fun unzipEncrypted(
        zip: File, destDir: File, subfolder: Boolean, password: String, onFile: (String) -> Unit
    ): File {
        val target = if (subfolder) uniqueTarget(destDir, zip.nameWithoutExtension.ifEmpty { "extract" }) else destDir
        target.mkdirs()
        val canon = target.canonicalPath
        val zf = net.lingala.zip4j.ZipFile(zip, password.toCharArray())
        val headers = zf.getFileHeaders()
        for (h in headers) {
            currentCoroutineContext().ensureActive()
            val name = h.getFileName()
            val out0 = File(target, name)
            if (!out0.canonicalPath.startsWith(canon + File.separator)) {
                throw IOException("Unsafe zip entry: $name")
            }
            zf.extractFile(h, target.absolutePath)
            if (!h.isDirectory()) onFile(name.substringAfterLast('/'))
        }
        return target
    }

    /** Bagi file jadi volume nama.zip.001, .002, ... lalu hapus file aslinya. */
    suspend fun splitFile(f: File, part: Long) {
        val buf = ByteArray(256 * 1024)
        var idx = 1
        f.inputStream().use { input ->
            while (true) {
                val outF = File(f.parentFile, f.name + String.format(Locale.US, ".%03d", idx))
                var written = 0L
                var any = false
                outF.outputStream().use { out ->
                    while (written < part) {
                        val want = minOf(buf.size.toLong(), part - written).toInt()
                        val n = input.read(buf, 0, want)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        written += n
                        any = true
                        currentCoroutineContext().ensureActive()
                    }
                }
                if (!any) {
                    outF.delete()
                    break
                }
                idx++
                if (written < part) break
            }
        }
        f.delete()
    }

    fun deleteParts(base: File) {
        var idx = 1
        while (true) {
            val p = File(base.parentFile, base.name + String.format(Locale.US, ".%03d", idx))
            if (!p.exists()) break
            p.delete()
            idx++
        }
    }

    fun countParts(first: File): Int {
        val base = first.name.removeSuffix(".001")
        var idx = 1
        while (File(first.parentFile, base + String.format(Locale.US, ".%03d", idx)).exists()) idx++
        return idx - 1
    }

    /** Gabungkan nama.zip.001, .002, ... menjadi satu file. */
    suspend fun joinParts(first: File, out: File, onPart: (String) -> Unit) {
        val base = first.name.removeSuffix(".001")
        val buf = ByteArray(256 * 1024)
        out.outputStream().use { o ->
            var idx = 1
            while (true) {
                val p = File(first.parentFile, base + String.format(Locale.US, ".%03d", idx))
                if (!p.exists()) break
                p.inputStream().use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        currentCoroutineContext().ensureActive()
                    }
                }
                onPart(p.name)
                idx++
            }
        }
    }

    private suspend fun addToZip(zos: ZipOutputStream, f: File, entry: String, skip: File, onFile: (String) -> Unit) {
        currentCoroutineContext().ensureActive()
        if (f.absolutePath == skip.absolutePath) return
        if (f.isDirectory) {
            if (isLink(f)) return
            zos.putNextEntry(ZipEntry("$entry/"))
            zos.closeEntry()
            f.listFiles()?.forEach { addToZip(zos, it, "$entry/${it.name}", skip, onFile) }
        } else {
            val e = ZipEntry(entry)
            e.time = f.lastModified()
            zos.putNextEntry(e)
            f.inputStream().use { input ->
                val buf = ByteArray(128 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    zos.write(buf, 0, n)
                    currentCoroutineContext().ensureActive()
                }
            }
            zos.closeEntry()
            onFile(f.name)
        }
    }

    fun zipCount(zip: File): Int = ZipFile(zip).use { it.size() }

    suspend fun unzip(zip: File, destDir: File, subfolder: Boolean, onFile: (String) -> Unit): File {
        val target = if (subfolder) uniqueTarget(destDir, zip.nameWithoutExtension.ifEmpty { "ekstrak" }) else destDir
        target.mkdirs()
        val canonTarget = target.canonicalPath
        ZipFile(zip).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                currentCoroutineContext().ensureActive()
                val e = entries.nextElement()
                val out0 = File(target, e.name)
                if (!out0.canonicalPath.startsWith(canonTarget + File.separator)) {
                    throw IOException("Unsafe zip entry: ${e.name}")
                }
                if (e.isDirectory) {
                    out0.mkdirs()
                } else {
                    out0.parentFile?.mkdirs()
                    // "Ekstrak disini": jangan menimpa file yang sudah ada
                    val out = if (subfolder) out0 else uniqueTarget(out0.parentFile ?: target, out0.name)
                    zf.getInputStream(e).use { input ->
                        out.outputStream().use { output ->
                            val buf = ByteArray(128 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                currentCoroutineContext().ensureActive()
                            }
                        }
                    }
                    if (e.time > 0) out.setLastModified(e.time)
                    onFile(out.name)
                }
            }
        }
        return target
    }

    /** Daftar isi arsip (maks [limit] entri) dan total entri. */
    fun listZip(zip: File, limit: Int): Pair<List<Pair<String, Long>>, Int> {
        return ZipFile(zip).use { zf ->
            val out = ArrayList<Pair<String, Long>>()
            val en = zf.entries()
            var total = 0
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                total++
                if (out.size < limit) out.add(e.name to e.size)
            }
            out to total
        }
    }

    /** Uji integritas arsip: baca semua entri sampai habis (CRC dicek otomatis). */
    suspend fun testZip(zip: File, onFile: (String) -> Unit): Int {
        var n = 0
        ZipFile(zip).use { zf ->
            val en = zf.entries()
            val buf = ByteArray(64 * 1024)
            while (en.hasMoreElements()) {
                currentCoroutineContext().ensureActive()
                val e = en.nextElement()
                if (!e.isDirectory) {
                    zf.getInputStream(e).use { ins ->
                        while (ins.read(buf) >= 0) {
                            currentCoroutineContext().ensureActive()
                        }
                    }
                    onFile(e.name.substringAfterLast('/'))
                }
                n++
            }
        }
        return n
    }

    /** Hitung total ukuran (byte) dan jumlah file. */
    suspend fun measure(root: File): Pair<Long, Int> {
        var bytes = 0L
        var count = 0
        val stack = ArrayList<File>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val f = stack.removeAt(stack.size - 1)
            if (f.isDirectory && !isLink(f)) {
                f.listFiles()?.let { stack.addAll(it) }
            } else {
                bytes += f.length()
                count++
            }
        }
        return bytes to count
    }
}
