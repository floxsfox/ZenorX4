package com.zenorx.files

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private class SheetAct(val icon: ImageVector, val label: String, val onClick: () -> Unit)

/** Menu bawah saat file diketuk (Instal, Lihat, Ekstrak, Kompres, dst). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileSheet(vm: FilesViewModel, req: SheetReq) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val item = req.item
    val f = item.file
    val p = vm.panel(req.panel)
    val ext = f.extension.lowercase()
    val zipLike = ext in extractableExt
    val isVolume = f.name.endsWith(".001")
    val thumb = rememberThumb(item)
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val acts = ArrayList<SheetAct>()
    fun add(icon: ImageVector, label: String, onClick: () -> Unit) {
        acts.add(SheetAct(icon, label) { vm.sheet = null; onClick() })
    }

    if (item.kind == FileKind.APK) {
        add(Icons.Filled.OpenInNew, stringResource(R.string.act_install)) { vm.installApk(ctx, f) }
    }
    if (zipLike) {
        add(Icons.Filled.Visibility, stringResource(R.string.act_view)) { vm.viewArchive(f) }
        add(Icons.Filled.Unarchive, stringResource(R.string.act_extract_here)) { vm.extractHere(f, p.path) }
        add(Icons.Filled.Unarchive, stringResource(R.string.extract_to, f.nameWithoutExtension)) {
            vm.extractFolder(f, p.path)
        }
        add(Icons.Filled.CheckBox, stringResource(R.string.act_test)) { vm.testArchive(f) }
    } else if (isVolume) {
        add(Icons.Filled.Archive, stringResource(R.string.act_merge_volumes)) { vm.joinVolumes(f) }
        add(Icons.Filled.OpenInNew, stringResource(R.string.act_open_with)) { vm.openWith(ctx, f, true) }
    } else if (isEditable(f)) {
        add(Icons.Filled.Edit, stringResource(R.string.act_edit)) { vm.editing = f }
        add(Icons.Filled.OpenInNew, stringResource(R.string.act_open_with)) { vm.openWith(ctx, f, true) }
    } else {
        add(Icons.Filled.OpenInNew, stringResource(R.string.act_open)) { vm.openWith(ctx, f, false) }
        add(Icons.Filled.OpenInNew, stringResource(R.string.act_open_with)) { vm.openWith(ctx, f, true) }
    }
    add(Icons.Filled.DoneAll, stringResource(R.string.act_select)) { vm.multi = true; vm.toggle(p, item) }
    add(Icons.Filled.Archive, stringResource(R.string.act_compress_zip)) { vm.compress(listOf(f), p.path) }
    add(Icons.Filled.Archive, stringResource(R.string.act_compress_more)) {
        vm.dlg = Dlg.CreateArchive(listOf(f), p.path)
    }
    add(Icons.Filled.ContentCopy, stringResource(R.string.copy)) { vm.putClip(listOf(f), false) }
    add(Icons.Filled.ContentCut, stringResource(R.string.cut)) { vm.putClip(listOf(f), true) }
    add(Icons.Filled.Edit, stringResource(R.string.rename)) { vm.dlg = Dlg.Rename(f) }
    add(Icons.Filled.Share, stringResource(R.string.share)) { vm.share(ctx, listOf(f)) }
    add(Icons.Filled.Delete, stringResource(R.string.delete)) { vm.dlg = Dlg.Delete(listOf(f)) }
    add(Icons.Filled.Info, stringResource(R.string.properties)) { vm.showProps(f) }

    ModalBottomSheet(
        onDismissRequest = { vm.sheet = null },
        sheetState = state,
        containerColor = cs.surface
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 20.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBox(item, thumb, false, false, 48.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.name, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurface
                    )
                    Text(
                        humanSize(item.size) + (thumb?.extra?.let { " • $it" } ?: ""),
                        fontSize = 12.sp, color = cs.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Box(Modifier.fillMaxWidth().padding(top = 6.dp).height(1.5.dp).background(cs.primary))
            acts.forEach { a ->
                Row(
                    Modifier.fillMaxWidth().height(54.dp).clickable { a.onClick() }.padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(a.icon, null, tint = cs.onSurface, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(24.dp))
                    Text(a.label, fontSize = 17.sp, color = cs.onSurface)
                }
            }
        }
    }
}

/** Isi arsip (zip/jar/apk) dalam layar penuh. */
@Composable
fun ArchiveDialog(vm: FilesViewModel, info: ArchiveInfo) {
    val cs = MaterialTheme.colorScheme
    val list = info.entries
    val err = info.error
    Dialog(
        onDismissRequest = { vm.archive = null },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            Column {
                Row(
                    Modifier.fillMaxWidth().background(LocalToolbar.current).height(56.dp).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.archive = null }) {
                        Icon(Icons.Filled.Close, stringResource(R.string.close), tint = Color.White)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            info.file.name, color = Color.White, fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (list == null) stringResource(R.string.reading)
                            else stringResource(R.string.n_entries, info.total),
                            color = Color(0xFFD0D0DC), fontSize = 12.sp
                        )
                    }
                }
                if (list == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = cs.primary)
                    }
                } else if (err != null) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(err, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list) { e ->
                            val isDir = e.first.endsWith("/")
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (isDir) Icons.Filled.Folder else Icons.Filled.Description, null,
                                    tint = if (isDir) Color(0xFFFFA726) else cs.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    e.first, fontSize = 13.sp, color = cs.onSurface,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (!isDir && e.second >= 0) {
                                    Spacer(Modifier.width(8.dp))
                                    Text(humanSize(e.second), fontSize = 11.sp, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionBtn(
    icon: ImageVector?,
    glyph: String?,
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val tint = if (selected) cs.primary else cs.onSurface
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.height(26.dp), contentAlignment = Alignment.Center) {
            if (icon != null) {
                Icon(icon, null, modifier = Modifier.size(26.dp), tint = tint)
            } else if (glyph != null) {
                Text(glyph, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = tint, maxLines = 1)
            }
        }
        Text(label, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = tint)
        Box(
            Modifier.padding(top = 3.dp).width(26.dp).height(3.dp)
                .background(if (selected) cs.primary else Color.Transparent)
        )
    }
}

/** "Jenis tampilan" + "Urutan" (dipakai di popup dan dialog). */
@Composable
fun ViewOptionsContent(vm: FilesViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.width(330.dp).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(
            stringResource(R.string.view_type), fontSize = 16.sp, color = cs.onSurface,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Row(Modifier.fillMaxWidth()) {
            OptionBtn(Icons.Filled.ViewList, null, stringResource(R.string.view_detail), vm.viewMode == ViewMode.DETAIL, Modifier.weight(1f)) {
                vm.changeViewMode(ViewMode.DETAIL)
            }
            OptionBtn(Icons.Filled.Menu, null, stringResource(R.string.view_compact), vm.viewMode == ViewMode.COMPACT, Modifier.weight(1f)) {
                vm.changeViewMode(ViewMode.COMPACT)
            }
            OptionBtn(Icons.Filled.ViewModule, null, stringResource(R.string.view_grid), vm.viewMode == ViewMode.GRID, Modifier.weight(1f)) {
                vm.changeViewMode(ViewMode.GRID)
            }
            OptionBtn(Icons.Filled.Folder, null, stringResource(R.string.view_categories), vm.categories, Modifier.weight(1.1f)) {
                vm.changeCategories(!vm.categories)
            }
            OptionBtn(
                if (vm.showHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff, null,
                stringResource(R.string.view_hidden), vm.showHidden, Modifier.weight(1.2f)
            ) { vm.changeHidden(!vm.showHidden) }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.sort_title), fontSize = 16.sp, color = cs.onSurface,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Row(Modifier.fillMaxWidth()) {
            OptionBtn(null, "A-Z", stringResource(R.string.sort_az), vm.sortBy == SortBy.NAME && vm.sortAsc, Modifier.weight(1f)) {
                vm.changeSort(SortBy.NAME, true)
            }
            OptionBtn(null, "Z-A", stringResource(R.string.sort_za), vm.sortBy == SortBy.NAME && !vm.sortAsc, Modifier.weight(1f)) {
                vm.changeSort(SortBy.NAME, false)
            }
            OptionBtn(Icons.Filled.Storage, null, stringResource(R.string.sort_size), vm.sortBy == SortBy.SIZE, Modifier.weight(1f)) {
                vm.changeSort(SortBy.SIZE, vm.sortAsc)
            }
            OptionBtn(Icons.Filled.DateRange, null, stringResource(R.string.sort_date), vm.sortBy == SortBy.DATE, Modifier.weight(1f)) {
                vm.changeSort(SortBy.DATE, vm.sortAsc)
            }
            OptionBtn(Icons.Filled.Description, null, stringResource(R.string.sort_type), vm.sortBy == SortBy.TYPE, Modifier.weight(1f)) {
                vm.changeSort(SortBy.TYPE, vm.sortAsc)
            }
            OptionBtn(
                Icons.Filled.SwapVert, null, stringResource(R.string.sort_desc),
                !vm.sortAsc && vm.sortBy != SortBy.NAME, Modifier.weight(1.2f)
            ) { vm.changeSort(vm.sortBy, !vm.sortAsc) }
        }
    }
}
