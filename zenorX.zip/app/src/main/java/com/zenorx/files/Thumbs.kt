package com.zenorx.files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

@Immutable
class Thumb(val image: ImageBitmap?, val extra: String?)

/**
 * Pemuat thumbnail asinkron (di thread IO, maksimal 3 sekaligus) dengan cache memori.
 * Mendukung gambar, video, APK (ikon aplikasi), audio (cover album), dan PDF.
 */
object Thumbs {
    private const val PX = 160

    private val cache = object : LruCache<String, Thumb>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Thumb): Int {
            val b = value.image ?: return 128
            return b.width * b.height * 4 + 128
        }
    }
    private val counts = LruCache<String, Int>(3000)
    private val gate = Semaphore(3)

    private fun key(item: FileItem) = "${item.path}|${item.modified}"

    fun wants(k: FileKind): Boolean =
        k == FileKind.IMAGE || k == FileKind.VIDEO || k == FileKind.APK ||
            k == FileKind.AUDIO || k == FileKind.PDF

    fun peek(item: FileItem): Thumb? = cache.get(key(item))

    suspend fun load(ctx: Context, item: FileItem): Thumb {
        val k = key(item)
        val hit = cache.get(k)
        if (hit != null) return hit
        val t = gate.withPermit { withContext(Dispatchers.IO) { make(ctx, item) } }
        cache.put(k, t)
        return t
    }

    fun peekCount(item: FileItem): Int? = counts.get(key(item))

    suspend fun count(item: FileItem): Int {
        val k = key(item)
        val hit = counts.get(k)
        if (hit != null) return hit
        val n = withContext(Dispatchers.IO) { item.file.list()?.size ?: 0 }
        counts.put(k, n)
        return n
    }

    private fun make(ctx: Context, item: FileItem): Thumb = try {
        when (item.kind) {
            FileKind.IMAGE -> image(item)
            FileKind.VIDEO -> video(item)
            FileKind.AUDIO -> audio(item)
            FileKind.APK -> apk(ctx, item)
            FileKind.PDF -> pdf(item)
            else -> Thumb(null, null)
        }
    } catch (e: Throwable) {
        Thumb(null, null)
    }

    private fun fit(src: Bitmap): Bitmap {
        val m = minOf(src.width, src.height)
        if (m <= PX) return src
        val sc = PX.toFloat() / m
        val w = (src.width * sc).toInt().coerceAtLeast(1)
        val h = (src.height * sc).toInt().coerceAtLeast(1)
        val out = Bitmap.createScaledBitmap(src, w, h, true)
        if (out !== src) src.recycle()
        return out
    }

    private fun image(item: FileItem): Thumb {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(item.path, o)
        val w = o.outWidth
        val h = o.outHeight
        if (w <= 0 || h <= 0) return Thumb(null, null)
        var s = 1
        while (minOf(w, h) / (s * 2) >= PX) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bmp = BitmapFactory.decodeFile(item.path, o2)
        return Thumb(bmp?.asImageBitmap(), "${w}x$h")
    }

    private fun video(item: FileItem): Thumb {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(item.path)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val parts = ArrayList<String>()
            if (dur != null) parts.add(formatDuration(dur))
            if (w != null && h != null) parts.add("${w}x$h")
            val frame = r.getFrameAtTime()
            val img = if (frame != null) fit(frame).asImageBitmap() else null
            return Thumb(img, if (parts.isEmpty()) null else parts.joinToString(" • "))
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun audio(item: FileItem): Thumb {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(item.path)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val pic = r.embeddedPicture
            var img: ImageBitmap? = null
            if (pic != null) {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(pic, 0, pic.size, o)
                var s = 1
                while (o.outWidth > 0 && minOf(o.outWidth, o.outHeight) / (s * 2) >= PX) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                img = BitmapFactory.decodeByteArray(pic, 0, pic.size, o2)?.asImageBitmap()
            }
            return Thumb(img, if (dur != null) formatDuration(dur) else null)
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun apk(ctx: Context, item: FileItem): Thumb {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(item.path, 0) ?: return Thumb(null, null)
        val ai = info.applicationInfo ?: return Thumb(null, null)
        ai.sourceDir = item.path
        ai.publicSourceDir = item.path
        val icon = ai.loadIcon(pm).toBitmap(PX, PX)
        val label = ai.loadLabel(pm).toString()
        val ver = info.versionName
        val extra = if (ver != null) "$label • v$ver" else label
        return Thumb(icon.asImageBitmap(), extra)
    }

    private fun pdf(item: FileItem): Thumb {
        val pfd = ParcelFileDescriptor.open(item.file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val renderer = PdfRenderer(pfd)
            try {
                val pages = renderer.pageCount
                if (pages <= 0) return Thumb(null, null)
                val page = renderer.openPage(0)
                try {
                    val sc = PX.toFloat() / minOf(page.width, page.height)
                    val w = (page.width * sc).toInt().coerceAtLeast(1)
                    val h = (page.height * sc).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Thumb(bmp.asImageBitmap(), "$pages p")
                } finally {
                    page.close()
                }
            } finally {
                renderer.close()
            }
        } finally {
            try {
                pfd.close()
            } catch (e: Exception) {
            }
        }
    }
}
