package com.zenorx.files

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val Orange = Color(0xFFE95420)
val Aubergine = Color(0xFF3B0A2D)
val DualBarColor = Color(0xFF151515)

class Palette(val labelRes: Int, val accent: Color, val toolbar: Color)

val ZxRed = Color(0xFFE5202D)

val Palettes = listOf(
    Palette(R.string.palette_zx, ZxRed, Color(0xFF151515)),
    Palette(R.string.palette_ubuntu, Orange, Aubergine),
    Palette(R.string.palette_blue, Color(0xFF6C8EE3), Color(0xFF2B3044))
)

val LocalToolbar = compositionLocalOf { Color(0xFF151515) }

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color.White,
    secondary = accent,
    onSecondary = Color.White,
    background = Color(0xFF1A1A1A),
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF2A2A2A),
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF333333),
    onSurfaceVariant = Color(0xFFA8A8A8),
    secondaryContainer = Color(0xFF3A3A3A),
    onSecondaryContainer = Color.White,
    outline = Color(0xFF4A4A4A),
    error = Color(0xFFFF6B6B),
    surfaceContainer = Color(0xFF2F3140),
    surfaceContainerHigh = Color(0xFF2F3140),
    surfaceContainerHighest = Color(0xFF3A3C4C)
)

private fun lightScheme(accent: Color) = lightColorScheme(
    primary = accent,
    onPrimary = Color.White,
    secondary = accent,
    onSecondary = Color.White,
    background = Color(0xFFF6F5F4),
    onBackground = Color(0xFF2B2B2B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF2B2B2B),
    surfaceVariant = Color(0xFFEAE8E6),
    onSurfaceVariant = Color(0xFF666666),
    secondaryContainer = Color(0xFFE8E6E4),
    onSecondaryContainer = Color(0xFF2B2B2B),
    outline = Color(0xFFCDC7C2),
    error = Color(0xFFC7162B),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFFFFFFF),
    surfaceContainerHighest = Color(0xFFF0EEEC)
)

@Composable
fun ZenorXTheme(dark: Boolean, palette: Int, content: @Composable () -> Unit) {
    val pal = Palettes.getOrElse(palette) { Palettes[0] }
    val scheme = if (dark) darkScheme(pal.accent) else lightScheme(pal.accent)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            @Suppress("DEPRECATION")
            window.navigationBarColor = scheme.background.toArgb()
            val ctl = WindowCompat.getInsetsController(window, view)
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalToolbar provides pal.toolbar) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
