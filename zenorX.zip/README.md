# zenorX 2.1

Manajer file Android (Kotlin + Jetpack Compose).

- Tampilan utama gaya ZArchiver, dual panel gaya MT Manager (ikon kolom di toolbar)
- Kategori: Folder, lalu File, lalu Arsip; urutan A-Z, Z-A, ukuran, tanggal, jenis
- Ketuk file -> menu bawah (Instal, Lihat, Ekstrak, Coba, Kompres, Salin, Potong, ...)
- Tombol + : Folder baru, File baru, Buat arsip (zip, level, sandi ZipCrypto/AES, volume), Tempel
- Editor kode: highlight, garis indentasi, cek sintaks (baris hijau/merah), Undo/Redo, Play (HTML, JS, Python, Markdown)
- Bahasa mengikuti bahasa ponsel (Inggris & Indonesia; bahasa lain jatuh ke Inggris)
- Build RELEASE (R8), ditandatangani app/zenorx-release.jks

## Build lewat GitHub (dari ponsel)
1. `.github/workflows/zenorx.yml` <- isi dari `zenorx.yml` (sekali saja)
2. Unggah `zenorX.zip` ke root repo (timpa yang lama) -> Commit. ZIP tetap tersimpan; bot hanya membuka ZIP di server untuk build.
3. Tab Actions -> unduh artifact `zenorX-release-apk`, atau ambil dari Releases -> "latest".

## Menambah bahasa
Salin `app/src/main/res/values/strings.xml` ke `values-xx/strings.xml` (xx = kode bahasa), terjemahkan isinya,
lalu tambahkan `<locale android:name="xx" />` di `res/xml/locales_config.xml`.
